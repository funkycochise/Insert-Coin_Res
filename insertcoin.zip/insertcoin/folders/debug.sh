 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="__Debug"

cd $OutputRoot

create "$MainDir"

orientation=$2

if [ -z "$orientation" ] || [ "$orientation" = "V" ];
then
   addgame "Noboranka (bootleg).mra" "_Noboranka"
   addgame "Rafflesia (315-5162).mra" "_Rafflesia"
   addgame "Regulus (World, 315-5033, Rev A.).mra" "_Regulus"
   addgame "Star Jacker (alt).mra" "_Star Jacker"
   addgame "Star Jacker.mra" "_Star Jacker"
   addgame "SWAT (World, 315-5048).mra" "_Swat"
   addgame "Up'n Down (World, 315-5030).mra" "_Up'n Down"
   addgame "Water Match (World, 315-5064).mra" "_Water Match"
fi
exit 0