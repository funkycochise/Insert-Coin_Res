 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega"

cd $OutputRoot

create "$MainDir"

orientation=$2

if [ -z "$orientation" ] || [ "$orientation" = "V" ];
then
   #special_echo "\$orientation is empty or V"
   addgame "Future Spy.mra" "_Future Spy"
   addgame "Pengo (Set 1, Rev C).mra" "_Pengo"
   addgame "Super Zaxxon.mra" "_Super Zaxxon"
   addgame "zaxxon.mra" "_Zaxxon"
fi
#if [ -z "$orientation" ] || [ "$orientation" = "H" ];
#then
#   #special_echo "\$orientation is empty or H"
   addgame "BankPanic.mra" "_BankPanic"
#fi

exit 0