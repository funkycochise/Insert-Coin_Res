# redirect stdout/stderr to a file
#exec >run.txt 2>&1

exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null

launchdir=$1
#special_echo "launchdir $launchdir"

OutputRoot=/media/fat/_Arcade/_Coin-Op
special_echo "Creating $OutputRoot/"
if [ -d "$OutputRoot" ]; then
   rm -r $OutputRoot >/dev/null
fi
mkdir -p $OutputRoot


sh ./folders/atari.sh "$OutputRoot" 
sh ./folders/bagman.sh "$OutputRoot" 
sh ./folders/Ballymidway.sh "$OutputRoot" 
sh ./folders/capcom.sh "$OutputRoot"
sh ./folders/cave.sh "$OutputRoot" 
sh ./folders/cps1.sh "$OutputRoot" 
sh ./folders/cps1.5.sh "$OutputRoot" 
sh ./folders/cps2.sh "$OutputRoot" 
sh ./folders/crazykong.sh "$OutputRoot"
sh ./folders/deco.sh "$OutputRoot"
sh ./folders/galaxian.sh "$OutputRoot"
sh ./folders/gottlieb.sh "$OutputRoot" 
sh ./folders/irem.sh "$OutputRoot" 
sh ./folders/iremm62.sh "$OutputRoot" 
sh ./folders/iremm72.sh "$OutputRoot" 
sh ./folders/jaleco.sh "$OutputRoot" 
sh ./folders/konami.sh "$OutputRoot" 
sh ./folders/ladybug.sh "$OutputRoot" 
#sh ./folders/mcr1.sh "$OutputRoot" 
#sh ./folders/mcr2.sh "$OutputRoot"
#sh ./folders/mcr3.sh "$OutputRoot"
#sh ./folders/mcr3mono.sh "$OutputRoot" 
#sh ./folders/mcr3scroll.sh "$OutputRoot" 
sh ./folders/namco.sh "$OutputRoot" 
sh ./folders/neogeo.sh "$OutputRoot" 
sh ./folders/nichibutsu.sh "$OutputRoot" 
sh ./folders/nintendo.sh "$OutputRoot" 
sh ./folders/pacman.sh "$OutputRoot"
sh ./folders/raizing.sh "$OutputRoot" 
sh ./folders/robotron.sh "$OutputRoot"
sh ./folders/scramble.sh "$OutputRoot"
sh ./folders/sega.sh "$OutputRoot"
sh ./folders/segasys1.sh "$OutputRoot"
sh ./folders/segasys2.sh "$OutputRoot"
sh ./folders/segasys16.sh "$OutputRoot"
sh ./folders/segasyse.sh "$OutputRoot"
sh ./folders/snk.sh "$OutputRoot"
sh ./folders/si.sh "$OutputRoot"
sh ./folders/taito.sh "$OutputRoot"
sh ./folders/technos.sh "$OutputRoot"
sh ./folders/Tehkan-Tecmo.sh "$OutputRoot"
sh ./folders/toaplan.sh "$OutputRoot"
sh ./folders/universal.sh "$OutputRoot"
sh ./folders/upl.sh "$OutputRoot"
sh ./folders/williams.sh "$OutputRoot"

sh ./folders/newest.sh "$OutputRoot"
sh ./folders/vertical.sh "$OutputRoot"
sh ./folders/horizontal.sh "$OutputRoot"