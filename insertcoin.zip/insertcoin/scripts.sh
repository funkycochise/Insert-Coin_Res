#!/bin/bash

TEMP=/media/fat/scripts/temp
RESURL=https://raw.githubusercontent.com/funkycochise/Insert-Coin/main
launchdir=$1

if ! [ -d "$TEMP" ]; then
  mkdir $TEMP
fi

function upd {
FILE=$launchdir/$1
if  test -f "$FILE"; then
   #file does exist
   curl $RESURL/$1 -O -k
   mv $TEMP/$1 $launchdir/$1 
fi

}


#echo "Done"
echo "launchdir $launchdir"
#special_echo "Getting latest insertcoin scripts"
echo "Getting latest insertcoin scripts"
cd $TEMP
upd "update_console.sh"
upd "update_main_mister.sh"


