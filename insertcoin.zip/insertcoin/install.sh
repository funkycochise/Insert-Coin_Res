﻿#!/bin/bash
clear
#exec 3>&1
RED='\033[0;31m'
NC='\033[0m' # No Color
special_echo () {
    echo -e "$@" >&3
}
exec &>/dev/null

launchdir=$1
#special_echo "launchdir $launchdir"
#echo "launchdir $launchdir"

ZP="Arcade_missing.zip"
TEMP=/media/fat/scripts/temp
ARCADE=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives
MAME=/media/fat/games/mame
MAMEUSB=/media/usb0/games/mame
MAMECIFS=/media/fat/cifs/games/mame
ARCHIVE_MERGED=https://ia802504.us.archive.org/1/items/mame-merged/mame-merged

function installfolder {
if [ -d "$ALT/$1" ]; then
   #dir exists, remove
   rm -r "$ALT/$1" >/dev/null
fi
mv -v "$TEMP/_Arcade/_alternatives/$1" "$ALT" >/dev/null
}

function completefolder {
if [ -d "$ALT/$1" ]; then
   #dir exists
   cp "$TEMP/_Arcade/_alternatives/$1/*.mra" "$ALT/$1" >/dev/null
else
   mv -v "$TEMP/_Arcade/_alternatives/$1" "$ALT" >/dev/null
fi
}

function dl {

if ! [ -d "$MAME" ]; then
  mkdir $MAME
fi

FILE=$MAME/$1
if ! test -f "$FILE"; then
   #file doesn not exists
   special_echo "$1"
   curl $ARCHIVE_MERGED/$1 -O -k
   mv $TEMP/$1 $MAME/$1 
#else
#   special_echo "$1 already exixts"
fi

}

function mame {

if [ -d "$MAMEUSB" ]; then
  mametarget=$MAMEUSB
elif [ -d "$MAMECIFS" ]; then
  mametarget=$MAMECIFS
else
  mametarget=$MAME
  if ! [ -d "$MAME" ]; then
    mkdir $MAME
  fi
fi

rm -r "$mametarget/$1" >/dev/null
mv -v "$TEMP/_Arcade/$1" "$mametarget"

}


special_echo "${RED}"
special_echo " ██▓ ███▄    █   ██████ ▓█████  ██▀███  ▄▄▄█████▓    ▄████▄  ▒█████   ██▓ ███▄    █ "
special_echo "▓██▒ ██ ▀█   █ ▒██    ▒ ▓█   ▀ ▓██ ▒ ██▒▓  ██▒ ▓▒   ▒██▀ ▀█ ▒██▒  ██▒▓██▒ ██ ▀█   █ "
special_echo "▒██▒▓██  ▀█ ██▒░ ▓██▄   ▒███   ▓██ ░▄█ ▒▒ ▓██░ ▒░   ▒▓█    ▄▒██░  ██▒▒██▒▓██  ▀█ ██▒"
special_echo "░██░▓██▒  ▐▌██▒  ▒   ██▒▒▓█  ▄ ▒██▀▀█▄  ░ ▓██▓ ░    ▒▓▓▄ ▄██▒██   ██░░██░▓██▒  ▐▌██▒"
special_echo "░██░▒██░   ▓██░▒██████▒▒░▒████▒░██▓ ▒██▒  ▒██▒ ░    ▒ ▓███▀ ░ ████▓▒░░██░▒██░   ▓██░"
special_echo "░▓  ░ ▒░   ▒ ▒ ▒ ▒▓▒ ▒ ░░░ ▒░ ░░ ▒▓ ░▒▓░  ▒ ░░      ░ ░▒ ▒  ░ ▒░▒░▒░ ░▓  ░ ▒░   ▒ ▒ "
special_echo " ▒ ░░ ░░   ░ ▒░░ ░▒  ░ ░ ░ ░  ░  ░▒ ░ ▒░    ░         ░  ▒    ░ ▒ ▒░  ▒ ░░ ░░   ░ ▒░"
special_echo " ▒ ░   ░   ░ ░ ░  ░  ░     ░     ░░   ░   ░         ░       ░ ░ ░ ▒   ▒ ░   ░   ░ ░ "
special_echo " ░           ░       ░     ░  ░   ░                 ░ ░         ░ ░   ░           ░ "
special_echo "                                                    ░                               "
special_echo "${NC}"
special_echo "Before launching this script, use update_all.sh with these options:Main, JTCORES, unofficial"
special_echo "and Misc/coin-op collection"
special_echo ""
special_echo "Updating insertcoin scripts"
sh ./scripts.sh $launchdir
special_echo "Downloading missing resources"
rm -r $TEMP
mkdir $TEMP
cd $TEMP
curl https://raw.githubusercontent.com/funkycochise/Insert-Coin/master/$ZP -O -k
special_echo "Unzipping missing resources"
unzip $ZP -d $TEMP >/dev/null
rm $ZP
special_echo "Installing missing resources"	
rm -r "$ALT/_Double Dragon/Double Dragon.mra"
mv -f $TEMP/_Arcade/*.mra $ARCADE

special_echo "SEGA System16 and Atari Tetris mras"
rm -r "$ALT/_Tetris" >/dev/null
rm -r "$ALT/_Atari Tetris" >/dev/null
installfolder "_Tetris"
installfolder "_Atari Tetris"

special_echo "SEGA System 1 and 2"
rm $ARCADE/cores/SEGASYS1_*.rbf
mv -v $TEMP/_Arcade/SEGASYS1_*.rbf $ARCADE/cores
installfolder "_Choplifter"
installfolder "_Gardia"
installfolder "_My Hero"
completefolder "_Pitfall II" 
installfolder "_Rafflesia"
installfolder "_Regulus"
installfolder "_Sega Ninja"
installfolder "_Spatter"
completefolder "_Star Jacker"
installfolder "_SWAT"
installfolder "_TeddyBoy Blues"
installfolder "_Toki no Senshi"
installfolder "_UFO Senshi Youko Chan"
installfolder "_Up'n Down"
installfolder "_Water Match"
installfolder "_Wonder Boy"
installfolder "_Wonder Boy in Monster Land" 

rm -r "$ALT/_Cave68K" >/dev/null
#mv -v "$TEMP/_Arcade/Fever SOS.mra" $ARCADE
mv -v "$TEMP/_Arcade/Gaia Crusaders.mra" $ARCADE
mv -v "$TEMP/_Arcade/Thunder Heroes.mra" $ARCADE

special_echo "SNK Neogeo arcade mras"
rm -r "$ARCADE/Bang Bang Busters.mra" >/dev/null
rm -r "$ARCADE/Metal Slug 2t.mra" >/dev/null
mame "neogeo.zip"
rm -r /media/fat/_Console/NeoGeo_20211228.rbf >/dev/null
rm -r /media/fat/_Console/NeoGeo-MVS_20211228.rbf >/dev/null
rm -r $ARCADE/cores/NeoGeo-MVS_*.rbf >/dev/null
mv -v $TEMP/_Arcade/NeoGeo-MVS_*.rbf $ARCADE/cores
mv -v "$TEMP/_Arcade/#neogeo.mgl" $ARCADE
#rm -r /media/fat/_Console/NeoGeo*.rbf >/dev/null
#mv -v $TEMP/_Console/NeoGeo*.rbf /media/fat/_Console/
rm -r $ALT/_Cabal
mv -v "$TEMP/_Arcade/Cabal.mra" $ARCADE

special_echo "SEGA System 16 mcu"
mame "s16mcu_alt.zip"

special_echo "Zaxxon samples"
mame "zaxxon_samples.zip"

special_echo "Gauntlet (Birdybro assignement hack)"
rm -r $ARCADE/cores/Gauntlet_*.rbf
mv -v $TEMP/_Arcade/Gauntlet_*.rbf $ARCADE/cores

special_echo "Gun.Smoke German West World version"
mv -v "$TEMP/_Arcade/_alternatives/_Gun.Smoke/Gun Smoke German.mra" "$ALT/_Gun.Smoke" >/dev/null

special_echo "Final Fight AE CPS2"
mame "ffightae_cps2_gfx.zip"
mame "ffightae_cps2_smp.zip"
mv -v "$TEMP/_Arcade/Final Fight AE CPS2 Patch.mra" $ARCADE

special_echo "Jaleco Psychic 5"
rm -r $ARCADE/cores/ikacore_Psychic5_*.rbf
mv -v "$TEMP/_Arcade/Psychic 5 (Japan).mra" $ARCADE
mv -v "$TEMP/_Arcade/Psychic 5 (World).mra" $ARCADE
mv -v $TEMP/_Arcade/ikacore_Psychic5_*.rbf $ARCADE/cores

special_echo "SNK alternatives"
installfolder "_Athena"
installfolder "_TNKIII"
installfolder "_Ikari Warriors"
installfolder "_Victory Road"

installfolder "_Ikari III - The Rescue"
mv -v "$TEMP/_Arcade/Ikari III - The Rescue (World Version 1, 8-Way Joystick).mra" $ARCADE

special_echo "sfa3ce mra"
mv -v "$TEMP/_Arcade/Street Fighter Alpha 3 Challenger's Edition (USA 980904).mra" $ARCADE
mv -v "$TEMP/_Arcade/Street Fighter Zero 3 Challenger's Edition (USA 980904).mra" $ARCADE

special_echo "Atari System1"
rm -r $ARCADE/cores/Arcade-Atarisys1*.rbf
mv -v $TEMP/_Arcade/Arcade-Atarisys1*.rbf $ARCADE/cores
mv -v "$TEMP/_Arcade/Indiana Jones.mra" $ARCADE
mv -v "$TEMP/_Arcade/Peter Pack Rat.mra" $ARCADE
mame "vindctr2.zip"

special_echo "Irem M72 alternatives"
installfolder "_R-Type"
installfolder "_X Multiply"
installfolder "_R-Type II"

special_echo "Raizing alternatives"
installfolder "_Batrider"
installfolder "_Battle Bakraid"
mv -v "$TEMP/_Arcade/Mahou Daisakusen (Japan).mra" $ARCADE
installfolder "_Battle Garegga"

special_echo "Nichibutsu alternatives"
mv -v "$TEMP/_Arcade/Legion - Spinner-87 (World ver 2.03).mra" $ARCADE
installfolder "_Legion - Spinner-87"

special_echo "UPL NinjaKun"
rm -r $ARCADE/cores/NinjaKun_*.rbf
mv -v "$TEMP/_Arcade/Ninjakun.mra" $ARCADE
mv -v "$TEMP/_Arcade/Raiders5.mra" $ARCADE
mv -v "$TEMP/_Arcade/Nova 2001.mra" $ARCADE
installfolder "_Nova 2001"
mv -v "$TEMP/_Arcade/NinjaKun_20221011.rbf" $ARCADE/cores

special_echo "Super Hang-On Limited edition fix"
completefolder "_Super Hang-On"

special_echo "SMS for SEGA System E"
rm -r $ARCADE/cores/SMS*.rbf
mv -v $TEMP/_Arcade/SMS_*.rbf $ARCADE/cores

special_echo "Capcom SonSon alternatives"
#rm -r $ARCADE/cores/Arcade-Sonson_*.rbf
#mv -v $TEMP/_Arcade/Arcade-Sonson_*.rbf $ARCADE/cores
#mv -v "$TEMP/_Arcade/SonSon.mra" $ARCADE
installfolder "_SonSon"

special_echo "Jaleco Exerion"
#rm -r $ARCADE/cores/Exerion_*.rbf
rm -r $ARCADE/Exerion.mra
#rm -r $ALT/_Exerion/Exerion.mra
#mv -v $TEMP/_Arcade/Exerion_*.rbf $ARCADE/cores
mv -v "$TEMP/_Arcade/Exerion (Jaleco).mra" $ARCADE
#mv -v "$TEMP/_Arcade/Exerion.mra" $ARCADE
completefolder "_Exerion"

special_echo "Irem Tropical Angel alternatives"
installfolder "_Tropical Angel"

#special_echo "SEGA Congo Bongo"
#rm -r $ARCADE/cores/Arcade-CongoBongo_*.rbf
#mv -v $TEMP/_Arcade/Arcade-CongoBongo_*.rbf $ARCADE/cores
#mv -v "$TEMP/_Arcade/Congo Bongo.mra" $ARCADE

special_echo "Express Raider alternatives"
installfolder "_ExpressRaider"
