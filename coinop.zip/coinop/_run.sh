# redirect stdout/stderr to a file
#exec >run.txt 2>&1

exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null

launchdir=$1
#special_echo "launchdir $launchdir"

sh ./install.sh $launchdir
sh ./mame.sh $launchdir

if test -f "$launchdir/test.sh"; then
   special_echo "testing test.sh"
   sh $launchdir/test.sh >/dev/null
fi

if test -f "$launchdir/update_console.sh"; then
   special_echo "Updating console cores"
   sh $launchdir/update_console.sh >/dev/null
fi

OutputRoot=/media/fat/_Arcade/_Coin-Op
special_echo "Creating $OutputRoot/"
if [ -d "$OutputRoot" ]; then
   rm -r $OutputRoot >/dev/null
fi
mkdir -p $OutputRoot

special_echo "Creating $OutputRoot/_Atari"
sh ./folders/atari.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Bagman"
sh ./folders/bagman.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Bally-Midway"
sh ./folders/Ballymidway.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Capcom-Mitchell"
sh ./folders/capcom.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Cave"
sh ./folders/cave.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_CPS1"
sh ./folders/cps1.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_CPS1.5"
sh ./folders/cps1.5.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_CPS2"
sh ./folders/cps2.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Crazy Kong"
sh ./folders/crazykong.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Data East-Deco"
sh ./folders/deco.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Galaxian"
sh ./folders/galaxian.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Gottlieb"
sh ./folders/gottlieb.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Irem"
sh ./folders/irem.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Irem-M62 "
sh ./folders/iremm62.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Jaleco"
sh ./folders/jaleco.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Konami"
sh ./folders/konami.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Ladybug"
sh ./folders/ladybug.sh "$OutputRoot" 

#special_echo "Creating $OutputRoot/_MCR1 "
#sh ./folders/mcr1.sh "$OutputRoot" 

#special_echo "Creating $OutputRoot/_MCR2 "
#sh ./folders/mcr2.sh "$OutputRoot"

#special_echo "Creating $OutputRoot/_MCR3 "
#sh ./folders/mcr3.sh "$OutputRoot"

#special_echo "Creating $OutputRoot/_MCR3Mono "
#sh ./folders/mcr3mono.sh "$OutputRoot" 

#special_echo "Creating $OutputRoot/_MCR3Scroll "
#sh ./folders/mcr3scroll.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Namco"
sh ./folders/namco.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Neo-geo"
sh ./folders/neogeo.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Nichibutsu"
sh ./folders/nichibutsu.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Nintendo"
sh ./folders/nintendo.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Pacman"
sh ./folders/pacman.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Raizing"
sh ./folders/raizing.sh "$OutputRoot" 

special_echo "Creating $OutputRoot/_Robotron"
sh ./folders/robotron.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Scramble"
sh ./folders/scramble.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Sega"
sh ./folders/sega.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Sega-System1"
sh ./folders/segasys1.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Sega-System2"
sh ./folders/segasys2.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Sega-System16"
sh ./folders/segasys16.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Sega-Systeme"
sh ./folders/segasyse.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_SNK"
sh ./folders/snk.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Space Invaders"
sh ./folders/si.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Taito"
sh ./folders/taito.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Technos"
sh ./folders/technos.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Tehkan-Tecmo"
sh ./folders/Tehkan-Tecmo.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Toaplan"
sh ./folders/toaplan.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Universal"
sh ./folders/universal.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Upl"
sh ./folders/upl.sh "$OutputRoot"

special_echo "Creating $OutputRoot/_Williams"
sh ./folders/williams.sh "$OutputRoot"

#special_echo "Getting missing mame roms"
#sh ./mamerom.sh
special_echo "Completed"

#special_echo "Finished !"


