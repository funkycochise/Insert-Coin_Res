﻿#!/bin/bash
clear
#exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null

launchdir=$1
#special_echo "launchdir $launchdir"
#echo "launchdir $launchdir"

TEMP=/media/fat/scripts/temp
RESURL=https://raw.githubusercontent.com/funkycochise/Coin-Op/main

function upd {

if ! [ -d "$TEMP" ]; then
  mkdir $TEMP
fi

FILE=$launchdir/$1
if  test -f "$FILE"; then
   #file does exist
   curl $RESURL/$1 -O -k
   mv $TEMP/$1 $launchdir/$1 
fi

}

special_echo "Getting latest coinop scripts"
cd $TEMP
dl "update_console.sh"
dl "update_main_mister.sh"

cd /media/fat
rm -r "$TEMP"





