 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Ladybug"

cd $OutputRoot

create "$MainDir"

addgame "Cosmic Avenger.mra" "_Cosmic Avenger"
addgame "Dorodon.mra" "_Dorodon"
addgame "Lady Bug.mra" "_Lady Bug"
addgame "Snap Jack.mra" "_Snap Jack"

exit 0