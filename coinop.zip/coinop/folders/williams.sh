 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Williams"

cd $OutputRoot

create "$MainDir"

copyfile "Alien Arena (Stargate upgrade).mra" "_Alien Arena"
copyfile "Alien Arena.mra" "_Alien Arena"
copyfile "Bubbles.mra" "_Bubbles"
copyfile "Colony 7 (Set 1).mra" "_Colony7"
copyfile "Colony 7.mra" "_Colony7"
copyfile "Defender (Red Label).mra" "_Defender"
copyfile "Defender.mra" "_Defender"
copyfile "Jin.mra" "_Jin"
copyfile "Joust.mra" "_Joust"
copyfile "Joust 2 - Survival of the Fittest (revision 2).mra" "_Joust 2"
copyfile "Mayday (Set 1).mra" "_Mayday"
copyfile "Mayday.mra" "_Mayday"
copyfile "Mystic Marathon.mra" "_Mystic Marathon"
copyfile "Playball (Prototype).mra" "_Playball"
copyfile "Robotron 2084.mra" "_Robotron"
copyfile "Sinistar.mra" "_Sinistar"
copyfile "Space Encounters.mra" "_Space Encounters"
copyfile "Splat!.mra" "_Splat"
copyfile "Stargate.mra" "_Stargate"
copyfile "Turkey Shoot - The Day They Took Over.mra" "_Turkey Shoot"

symlinkfolder "_Alien Arena"
symlinkfolder "_Bubbles"
symlinkfolder "_Colony7"
symlinkfolder "_Defender"
symlinkfolder "_Jin"
symlinkfolder "_Joust"
symlinkfolder "_Joust 2"
symlinkfolder "_Mayday"
symlinkfolder "_Mystic Marathon"
symlinkfolder "_Playball"
symlinkfolder "_Robotron"
symlinkfolder "_Sinistar"
symlinkfolder "_Space Encounters"
symlinkfolder "_Splat"
symlinkfolder "_Stargate"
symlinkfolder "_Turkey Shoot"

exit 0