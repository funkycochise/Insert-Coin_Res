 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Williams"

cd $OutputRoot

create "$MainDir"

createlinkfile "Alien Arena (Stargate upgrade).mra" "_Alien Arena"
createlinkfile "Alien Arena.mra" "_Alien Arena"
createlinkfile "Bubbles.mra" "_Bubbles"
createlinkfile "Colony 7 (Set 1).mra" "_Colony7"
createlinkfile "Colony 7.mra" "_Colony7"
createlinkfile "Defender (Red Label).mra" "_Defender"
createlinkfile "Defender.mra" "_Defender"
createlinkfile "Inferno (Williams).mra" "_Inferno"
createlinkfile "Jin.mra" "_Jin"
createlinkfile "Joust 2 - Survival of the Fittest (revision 2).mra" "_Joust 2"
createlinkfile "Joust.mra" "_Joust"
createlinkfile "Mayday (Set 1).mra" "_Mayday"
createlinkfile "Mayday.mra" "_Mayday"
createlinkfile "Mystic Marathon.mra" "_Mystic Marathon"
createlinkfile "Playball (Prototype).mra" "_Playball"
createlinkfile "Robotron 2084.mra" "_Robotron"
createlinkfile "Sinistar.mra" "_Sinistar"
createlinkfile "Space Encounters.mra" "_Space Encounters"
createlinkfile "Splat!.mra" "_Splat"
createlinkfile "Stargate.mra" "_Stargate"
createlinkfile "Turkey Shoot - The Day They Took Over.mra" "_Turkey Shoot"

symlinkfolder "_Alien Arena"
symlinkfolder "_Bubbles"
symlinkfolder "_Colony7"
symlinkfolder "_Defender"
symlinkfolder "_Inferno"
symlinkfolder "_Jin"
symlinkfolder "_Joust 2"
symlinkfolder "_Joust"
symlinkfolder "_Mayday"
symlinkfolder "_Mystic Marathon"
symlinkfolder "_Playball"
symlinkfolder "_Robotron"
symlinkfolder "_Sinistar"
symlinkfolder "_Space Encounters"
symlinkfolder "_Splat"
symlinkfolder "_Stargate"
symlinkfolder "_Turkey Shoot"

exit 0