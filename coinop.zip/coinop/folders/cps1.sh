 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_CPS1"

cd $OutputRoot

create "$MainDir"

if [ -z "$orientation" ] || [ "$orientation" = "V" ];
then
   special_echo "$MainDir $orientation is empty or V"
   addgame "1944 The Loop Master (Euro 000620).mra" "_1944 The Loop Master"
   addgame "19XX The War Against Destiny (Euro 960104).mra" "_19XX The War Against Destiny"
   addgame "Dimahoo (Euro 000121).mra" "_Dimahoo"
fi
if [ -z "$orientation" ] || [ "$orientation" = "H" ];
then
   special_echo "$MainDir $orientation is empty or H"
   addgame "Adventure Quiz Capcom World 2 -Japan 920611-.mra" "_Adventure Quiz Capcom World 2"
   addgame "Alien vs. Predator (Euro 940520).mra" "_Alien vs. Predator"
   addgame "Armored Warriors (Euro 941024).mra" "_Armored Warriors"
   addgame "Battle Circuit (Euro 970319).mra" "_Battle Circuit"
   addgame "Capcom Sports Club (Euro 971017).mra" "_Capcom Sports Club"
fi


exit 0