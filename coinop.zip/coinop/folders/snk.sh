 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

link "ASO.mra" "_ASO"
link "Athena.mra" "_Athena"

exit 0