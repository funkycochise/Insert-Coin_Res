 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

addgame "ASO.mra" "_ASO"
addgame "Athena.mra" "_Athena"
addgame "CountryClub.mra" "_CountryClub"
addgame "FightingGolf.mra" "_FightingGolf"
addgame "Ikari Warriors.mra" "_Ikari Warriors"
addgame "TNKIII.mra" "_TNKIII"
addgame "Victory Road.mra" "_Victory Road"
addgame "Prehistoric Isle in 1930 (World).mra" "_Prehistoric Isle in 1930"

exit 0