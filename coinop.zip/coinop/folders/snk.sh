 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

orientation=$2

if [ -z "$orientation" ] || [ "$orientation" = "V" ];
then
   #special_echo "\$orientation is empty or V"
   addgame "ASO.mra" "_ASO"
   addgame "FightingGolf.mra" "_FightingGolf"
   addgame "Ikari Warriors.mra" "_Ikari Warriors"
   addgame "TNKIII.mra" "_TNKIII"
   addgame "Victory Road.mra" "_Victory Road"
fi
if [ -z "$orientation" ] || [ "$orientation" = "H" ];
then
   #special_echo "\$orientation is empty or H"
   addgame "Athena.mra" "_Athena"
   addgame "CountryClub.mra" "_CountryClub"
   addgame "Prehistoric Isle in 1930 (World).mra" "_Prehistoric Isle in 1930"
exit 0