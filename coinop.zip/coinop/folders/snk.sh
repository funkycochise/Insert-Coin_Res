 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

copyfile "ASO.mra" "_ASO"

#copyfile "NeoGeo.mra" "_SNK"

symlinkfolder "_ASO"

#symlinkfolder "_SNK"

exit 0