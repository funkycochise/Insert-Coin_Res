 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

found=false
if  test -f "$RegSourceRoot/ASO.mra"; then
  copyfile "ASO.mra" "_ASO"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_ASO"
else
  rm -r "$ALT/_ASO" >/dev/null
fi

exit 0