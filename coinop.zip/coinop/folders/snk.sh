 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

found=false
if  test -f "$RegSourceRoot/ASO.mra"; then
  copyfile "ASO.mra" "_ASO"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_ASO"
else
  rm -r "$ALT/_ASO" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Athena.mra"; then
  copyfile "Athena.mra" "_Athena"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Athena"
else
  rm -r "$ALT/"_Athena" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/FightingGolf.mra"; then
  copyfile "FightingGolf.mra" "_FightingGolf"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_FightingGolf"
else
  rm -r "$ALT/"_FightingGolf" >/dev/null
fi

exit 0