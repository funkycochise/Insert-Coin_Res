 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

copyfile "ASO.mra" "_ASO"
copyfile "Athena.mra" "_Athena"
copyfile "FightingGolf.mra" "_FightingGolf"
copyfile "IkariWarriors_JP.mra" "_Ikari Warriors"
copyfile "TNKIII.mra" "_TNKIII"

symlinkfolder "_ASO"
symlinkfolder "_Athena"
symlinkfolder "_FightingGolf"
symlinkfolder "_Ikari Warriors"
symlinkfolder "_TNKIII"

exit 0