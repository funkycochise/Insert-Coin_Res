 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

copyfile "ASO.mra" "_ASO"
copyfile "Athena.mra" "_Athena"
copyfile "FightingGolf.mra" "_FightingGolf"
copyfile "Ikari Warriors.mra" "_Ikari Warriors"
copyfile "TNKIII.mra" "_TNKIII"
copyfile "Victory Road.mra" "_Victory Road"

symlinkfolder "_ASO"
symlinkfolder "_Athena"
symlinkfolder "_FightingGolf"
symlinkfolder "_Ikari Warriors"
symlinkfolder "_TNKIII"
symlinkfolder "_Victory Road"

exit 0