 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

found=false
if  test -f "$RegSourceRoot/ASO.mra"; then
  copyfile "ASO.mra" "_ASO"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_ASO"
else
  rm -r "$ALT/_ASO" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Athena.mra"; then
  copyfile "Athena.mra" "_Athena"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Athena"
else
  rm -r "$ALT/_Athena" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/CountryClub.mra"; then
  copyfile "CountryClub.mra" "_CountryClub"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_CountryClub"
else
  rm -r "$ALT/_CountryClub" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/FightingGolf.mra"; then
  copyfile "FightingGolf.mra" "_FightingGolf"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_FightingGolf"
else
  rm -r "$ALT/_FightingGolf" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Ikari Warriors.mra"; then
  copyfile "Ikari Warriors.mra" "_Ikari Warriors"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Ikari Warriors"
else
  rm -r "$ALT/_Ikari Warriors" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/TNKIII.mra"; then
  copyfile "TNKIII.mra" "_TNKIII"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_TNKIII"
else
  rm -r "$ALT/_TNKIII" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Victory Road.mra"; then
  copyfile "Victory Road.mra" "_Victory Road"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Victory Road"
else
  rm -r "$ALT/_Victory Road" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Prehistoric Isle in 1930 (World).mra"; then
  copyfile "Victory Road.mra" "_Prehistoric Isle in 1930"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Prehistoric Isle in 1930"
else
  rm -r "$ALT/_Prehistoric Isle in 1930" >/dev/null
fi

exit 0