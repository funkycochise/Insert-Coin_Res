 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"


copyfile "Alpha Mission.mra" "_Alpha Mission"
copyfile "Arian Mission.mra" "_Alpha Mission"
copyfile "ASO.mra" "_Alpha Mission"

copyfile "NeoGeo.mra" "_SNK"

symlinkfolder "_Alpha Mission"

#symlinkfolder "_SNK"

exit 0