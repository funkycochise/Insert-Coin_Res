 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_SNK"

cd $OutputRoot

create "$MainDir"

copyfile "ASO.mra" "_ASO"
copyfile "TNKIII.mra" "_TNKIII"

symlinkfolder "_ASO"
symlinkfolder "_TNKIII"

exit 0