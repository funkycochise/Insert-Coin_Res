 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem"

cd $OutputRoot

create "$MainDir"

addgame "Crazy Climber.mra" "_Crazy Climber"
addgame "Moon Patrol.mra" "_Moon Patrol"
addgame "Shot Rider (B-Board 89624B-1).mra" "_Shot Rider"
addgame "Shot Rider.mra" "_Shot Rider"
addgame "Traverse USA- Zippy Race (US).mra" "_Traverse USA"
addgame "Vigilante (World, Rev E).mra" "_Vigilante"


exit 0