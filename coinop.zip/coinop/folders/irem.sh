 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem"

cd $OutputRoot

create "$MainDir"

copyfile "Crazy Climber.mra" "_Crazy Climber"
copyfile "Moon Patrol.mra" "_Moon Patrol"
copyfile "R-Type (Japan).mra" "_R-Type"
copyfile "R-Type (World).mra" "_R-Type"
copyfile "Shot Rider (B-Board 89624B-1).mra" "_Shot Rider"
copyfile "Shot Rider.mra" "_Shot Rider"
copyfile "Traverse USA- Zippy Race (US).mra" "_Traverse USA"
copyfile "Vigilante (World, Rev E).mra" "_Vigilante"

symlinkfolder "_Crazy Climber"
symlinkfolder "_Moon Patrol"
symlinkfolder "_R-Type"
symlinkfolder "_Shot Rider"
symlinkfolder "_Traverse USA"
symlinkfolder "_Vigilante"

exit 0