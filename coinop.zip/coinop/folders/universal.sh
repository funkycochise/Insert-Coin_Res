 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Universal"

cd $OutputRoot

create "$MainDir"

addgame "Cosmic Alien.mra" "_Cosmic Alien"
addgame "Devil Zone.mra" "_Devil Zone"
addgame "Galaxy Wars (Universal, Set 1).mra" "_Galaxy Wars"
createlinkfile "Galaxy Wars.mra" "_Galaxy Wars"
addgame "Lady Bug.mra" "_Lady Bug"
addgame "Magical Spot.mra" "_Magical Spot"
addgame "Mr. Do! Fixed.mra" "_Mr. Do!"
createlinkfile "Mr. Do!.mra" "_Mr. Do!"
addgame "No Mans Land.mra" "_No Mans Land"
addgame "Snap Jack.mra" "_Snap Jack"
addgame "Space Panic.mra" "_Space Panic"

exit 0