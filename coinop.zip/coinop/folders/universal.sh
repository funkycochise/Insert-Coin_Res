 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Universal"

cd $OutputRoot

create "$MainDir"

copyfile "Cosmic Alien.mra" "_Cosmic Alien"
copyfile "Devil Zone.mra" "_Devil Zone"
copyfile "Galaxy Wars (Universal, Set 1).mra" "_Galaxy Wars"
copyfile "Galaxy Wars.mra" "_Galaxy Wars"
copyfile "Lady Bug.mra" "_Lady Bug"
copyfile "Magical Spot.mra" "_Magical Spot"
copyfile "Mr. Do! Fixed.mra" "_Mr. Do!"
copyfile "Mr. Do!.mra" "_Mr. Do!"
copyfile "No Mans Land.mra" "_No Mans Land"
copyfile "Snap Jack.mra" "_Snap Jack"
copyfile "Space Panic.mra" "_Space Panic"

symlinkfolder "_Cosmic Alien"
symlinkfolder "_Devil Zone"
symlinkfolder "_Galaxy Wars"
symlinkfolder "_Lady Bug"
symlinkfolder "_Magical Spot"
symlinkfolder "_Mr. Do!"
symlinkfolder "_No Mans Land"
symlinkfolder "_Snap Jack"
symlinkfolder "_Space Panic"

exit 0