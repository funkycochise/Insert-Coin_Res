 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Universal"

cd $OutputRoot

create "$MainDir"

copyfile "Cosmic Alien.mra" "_Cosmic Alien"
copyfile "Galaxy Wars (Universal, Set 1).mra" "_Galaxy Wars"
copyfile "Galaxy Wars.mra" "_Galaxy Wars"
copyfile "Lady Bug.mra" "_Lady Bug"
copyfile "Magical Spot.mra" "_Magical Spot"
copyfile "Mr. Do! Fixed.mra" "_Mr. Do!"
copyfile "Mr. Do!.mra" "_Mr. Do!"
copyfile "Space Panic.mra" "_Space Panic"

symlinkfolder "_Cosmic Alien"
symlinkfolder "_Galaxy Wars"
symlinkfolder "_Lady Bug"
symlinkfolder "_Magical Spot"
symlinkfolder "_Mr. Do!"
symlinkfolder "_Space Panic"

exit 0