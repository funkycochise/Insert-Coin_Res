 #!/bin/bash  

RegSourceRoot=/media/fat/_Arcade
AltSourceRoot=/media/fat/_Arcade/_alternatives

function create {
newFolder=$1
mkdir -p "${newFolder}"
}

function symlinkfolder {
if ([ -z "$2" ]); then 
   ln -s "$AltSourceRoot/$1"  "$OutputRoot/$MainDir/$1"
else
   #rename alternate folder
   ln -s "$AltSourceRoot/$1"  "$OutputRoot/$MainDir/$2"
fi
}

function createreplacefolder {

rm -r "$AltSourceRoot/$1"
mkdir -p "$AltSourceRoot/$1"
}

function copyfile {
echo "copying $RegSourceRoot/$1 to $AltSourceRoot/$2" >/dev/null

if ![ -d "$AltSourceRoot/$2" ]; then
   mkdir -p "$AltSourceRoot/$2"
fi
cp "$RegSourceRoot/$1" "$AltSourceRoot/$2"
}
