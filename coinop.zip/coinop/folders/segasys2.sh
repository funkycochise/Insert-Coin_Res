 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega-System2"

cd $OutputRoot

create "$MainDir"

createreplacefolder "_Toki no Senshi - Chrono Soldier"
createreplacefolder "_Brain"
createreplacefolder "_Heavy Metal"


copyfile "Choplifter (unprotected).mra" "_Choplifter"
copyfile "Toki no Senshi - Chrono Soldier (MC-8123, 317-0040).mra" "_Toki no Senshi - Chrono Soldier"
copyfile "Ufo Senshi Yohko Chan (MC-8123, 317-0064).mra" "_UFO Senshi Youko Chan"
copyfile "UFO Senshi Youko Chan (bootleg).mra" "_UFO Senshi Youko Chan"
copyfile "Wonder Boy in Monster Land (Japan New Ver., MC-8123, 317-0043).mra" "_Wonder Boy in Monster Land"
copyfile "Brain.mra" "_Brain"
copyfile "Heavy Metal (315-5135).mra" "_Heavy Metal"
copyfile "Wonder Boy (System 2, Set 1, Japan) [315-5177].mra" "_WonderBoy"

symlinkfolder "_Choplifter"
symlinkfolder "_Toki no Senshi - Chrono Soldier"
symlinkfolder "_UFO Senshi Youko Chan"
symlinkfolder "_WonderBoy" "_Wonder Boy"
symlinkfolder "_Wonder Boy in Monster Land"
symlinkfolder "_Brain"
symlinkfolder "_Heavy Metal"


exit 0