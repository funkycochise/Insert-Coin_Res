 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Bagman"

cd $OutputRoot

create "$MainDir"

addgame "Bagman.mra" "_Bagman"
addgame "Botanic (English, Spanish, Set 1).mra" "_Botanic"
createlinkfile "Botanic.mra" "_Botanic"
addgame "Pickin'.mra" "_Pickin"
addgame "Squash.mra" "_Squash"
addgame "Super Bagman.mra" "_Super Bagman"

exit 0