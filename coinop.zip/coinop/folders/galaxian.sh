 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Galaxian"

cd $OutputRoot

#create "$MainDir"

addgame "Azurian Attack.mra" "_Galaxian"
createlinkfile "Black Hole.mra" "_Galaxian"
createlinkfile "Catacomb.mra" "_Galaxian"
createlinkfile "Clean Sweep.mra" "_Galaxian"
createlinkfile "Devil Fish.mra" "_Galaxian"
createlinkfile "Galaxian.mra" "_Galaxian"
createlinkfile "King And Balloon.mra" "_Galaxian"
createlinkfile "Lucky Today.mra" "_Galaxian"
createlinkfile "Moon Cresta.mra" "_Galaxian"
createlinkfile "Mr. Do Nightmare.mra" "_Galaxian"
createlinkfile "Omega.mra" "_Galaxian"
createlinkfile "Orbitron.mra" "_Galaxian"
createlinkfile "Pisces.mra" "_Galaxian"
createlinkfile "UniWar S.mra" "_Galaxian"
createlinkfile "Victory.mra" "_Galaxian"
createlinkfile "War of the Bugs.mra" "_Galaxian"

exit 0