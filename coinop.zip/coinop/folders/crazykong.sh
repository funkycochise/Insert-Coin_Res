 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Crazy Kong"

cd $OutputRoot

#create "$MainDir"

addgame "Big Kong.mra" "_Crazy Kong"
addgame "Crazy Kong (Orca bootleg).mra" "_Crazy Kong"
createlinkfile "Crazy Kong Part II.mra" "_Crazy Kong"
createlinkfile "Donkey Kong (Spanish Crazy Kong bootleg).mra" "_Crazy Kong"

exit 0