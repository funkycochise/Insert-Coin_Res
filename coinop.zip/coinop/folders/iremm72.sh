 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M72 Hardware"
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

cd $OutputRoot

create "$MainDir"

addgame "Air Duel (Japan, M72 hardware).mra" "_Air Duel"
addgame "Daiku no Gensan (Japan, M72 hardware).mra" "_Daiku no Gensan"
addgame "Dragon Breed (Japan, M72 hardware).mra" "_Dragon Breed"
addgame "Gallop - Armed Police Unit (Japan, M72 hardware).mra" "_Gallop"
addgame "Image Fight (Japan).mra" "_Image Fight"
addgame "Image Fight (World).mra" "_Image Fight"
addgame "Legend of Hero Tonma (Japan).mra" "_Legend of Hero Tonma"
addgame "Mr. HELI no Daibouken (Japan).mra" "_Mr. HELI no Daibouken"
addgame "Ninja Spirit (Japan).mra" "_Ninja Spirit"
addgame "R-Type (Japan).mra" "_R-Type"
createlinkfile "R-Type (World).mra" "_R-Type"
addgame "X Multiply (Japan, M72 hardware).mra" "_X Multiply"
addgame "R-Type II (World).mra" "_R-Type II"
addgame "R-Type II (Japan).mra" "_R-Type II"

exit 0