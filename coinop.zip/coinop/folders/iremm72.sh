 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M72 Hardware"
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

cd $OutputRoot

create "$MainDir"

copyfile "Air Duel (Japan, M72 hardware).mra" "_Air Duel"
copyfile "Daiku no Gensan (Japan, M72 hardware).mra" "_Daiku no Gensan"
copyfile "Dragon Breed (Japan, M72 hardware).mra" "_Dragon Breed"
copyfile "Gallop - Armed Police Unit (Japan, M72 hardware).mra" "_Gallop"
copyfile "Image Fight (Japan).mra" "_Image Fight"
copyfile "Image Fight (World).mra" "_Image Fight"
copyfile "Legend of Hero Tonma (Japan).mra" "_Legend of Hero Tonma"
copyfile "Mr. HELI no Daibouken (Japan).mra" "_Mr. HELI no Daibouken"
copyfile "Ninja Spirit (Japan).mra" "_Ninja Spirit"
copyfile "R-Type (Japan).mra" "_R-Type"
copyfile "R-Type (World).mra" "_R-Type"
copyfile "X Multiply (Japan, M72 hardware).mra" "_X Multiply"

symlinkfolder "_Air Duel"
symlinkfolder "_Daiku no Gensan"
symlinkfolder "_Dragon Breed"
symlinkfolder "_Gallop"
symlinkfolder "_Image Fight"
symlinkfolder "_Legend of Hero Tonma"
symlinkfolder "_Mr. HELI no Daibouken"
symlinkfolder "_Ninja Spirit"
symlinkfolder "_R-Type"
symlinkfolder "_X Multiply"

exit 0