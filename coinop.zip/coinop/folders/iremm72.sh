 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M72 Hardware"
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

cd $OutputRoot

create "$MainDir"

function add {
if  test -f "$RegSourceRoot/$1"; then
   createlinkfile "$1" "$2"
   symlinkfolder "$2"
fi
}

add "Air Duel (Japan, M72 hardware).mra" "_Air Duel"
add "Daiku no Gensan (Japan, M72 hardware).mra" "_Daiku no Gensan"
add "Dragon Breed (Japan, M72 hardware).mra" "_Dragon Breed"
add "Gallop - Armed Police Unit (Japan, M72 hardware).mra" "_Gallop"
add "Image Fight (Japan).mra" "_Image Fight"
createlinkfile "Image Fight (World).mra" "_Image Fight"
add "Legend of Hero Tonma (Japan).mra" "_Legend of Hero Tonma"
add "Mr. HELI no Daibouken (Japan).mra" "_Mr. HELI no Daibouken"
add "Ninja Spirit (Japan).mra" "_Ninja Spirit"
add "R-Type (Japan).mra" "_R-Type"
createlinkfile "R-Type (World).mra" "_R-Type"
add "X Multiply (Japan, M72 hardware).mra" "_X Multiply"
add "R-Type II (World).mra" "_R-Type II"
createlinkfile "R-Type II (Japan).mra" "_R-Type II"

#if  test -f "$RegSourceRoot/Air Duel (Japan, M72 hardware).mra"; then
#   createlinkfile "Air Duel (Japan, M72 hardware).mra" "_Air Duel"
#   symlinkfolder "_Air Duel"
#fi
#if  test -f "$RegSourceRoot/Daiku no Gensan (Japan, M72 hardware).mra"; then
#   createlinkfile "Daiku no Gensan (Japan, M72 hardware).mra" "_Daiku no Gensan"
#   symlinkfolder "_Daiku no Gensan"
#fi
#if  test -f "$RegSourceRoot/Dragon Breed (Japan, M72 hardware).mra"; then
#   createlinkfile "Dragon Breed (Japan, M72 hardware).mra" "_Dragon Breed"
#   symlinkfolder "_Dragon Breed"
#fi
#if  test -f "$RegSourceRoot/Gallop - Armed Police Unit (Japan, M72 hardware).mra"; then
#   createlinkfile "Gallop - Armed Police Unit (Japan, M72 hardware).mra" "_Gallop"
#   symlinkfolder "_Gallop"
#fi
#if  test -f "$RegSourceRoot/Image Fight (Japan).mra"; then
#   createlinkfile "Image Fight (Japan).mra" "_Image Fight"
#   createlinkfile "Image Fight (World).mra" "_Image Fight"
#   symlinkfolder "_Image Fight"
#fi
#if  test -f "$RegSourceRoot/Legend of Hero Tonma (Japan).mra"; then
#   createlinkfile "Legend of Hero Tonma (Japan).mra" "_Legend of Hero Tonma"
#   symlinkfolder "_Legend of Hero Tonma"
#fi
#if  test -f "$RegSourceRoot/Mr. HELI no Daibouken (Japan).mra"; then
#   createlinkfile "Mr. HELI no Daibouken (Japan).mra" "_Mr. HELI no Daibouken"
#   symlinkfolder "_Mr. HELI no Daibouken"
#fi
#if  test -f "$RegSourceRoot/Ninja Spirit (Japan).mra.mra"; then
#   createlinkfile "Ninja Spirit (Japan).mra" "_Ninja Spirit"
#   symlinkfolder "_Ninja Spirit"
#fi
#if  test -f "$RegSourceRoot/R-Type (Japan).mra"; then
#   createlinkfile "R-Type (Japan).mra" "_R-Type"
#   createlin#kfile "R-Type (World).mra" "_R-Type"
#   symlinkfolder "_R-Type"
#fi
#if  test -f "$RegSourceRoot/X Multiply (Japan, M72 hardware).mra"; then
#   createlinkfile "X Multiply (Japan, M72 hardware).mra" "_X Multiply"
#   symlinkfolder "_X Multiply"
#fi
#if  test -f "$RegSourceRoot/R-Type II (World).mra"; then
#   createlinkfile "R-Type II (World).mra" "_R-Type II"
#   createlinkfile "R-Type II (Japan).mra" "_R-Type II"
#   symlinkfolder "_R-Type II"
#fi

exit 0