 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M72 Hardware"
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

cd $OutputRoot

create "$MainDir"

copyfile "Gallop - Armed Police Unit (Japan).mra" "_Gallop"
copyfile "Ninja Spirit (Japan).mra" "_Ninja Spirit"
copyfile "R-Type (Japan).mra" "_R-Type"
copyfile "R-Type (World).mra" "_R-Type"

symlinkfolder "_Gallop"
symlinkfolder "_Ninja Spirit"
symlinkfolder "_R-Type"

found=false
if  test -f "$RegSourceRoot/Image Fight (World).mra"; then
  copyfile "Image Fight (World).mra" "_Image Fight"
  found=true
fi
if  test -f "$RegSourceRoot/Image Fight (Japan).mra"; then
  copyfile "Image Fight (Japan).mra" "_Image Fight"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Image Fight"
else
rm -r "$ALT/_Image Fight" >/dev/null
fi
exit 0