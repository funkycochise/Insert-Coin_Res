 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M72 Hardware"
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

cd $OutputRoot

create "$MainDir"

copyfile "Gallop - Armed Police Unit (Japan).mra" "_Gallop"
copyfile "Ninja Spirit (Japan).mra" "_Ninja Spirit"
copyfile "R-Type (Japan).mra" "_R-Type"
copyfile "R-Type (World).mra" "_R-Type"
copyfile "Dragon Breed (Japan).mra" "_Dragon Breed"
copyfile "Legend of Hero Tonma (Japan).mra" "_Legend of Hero Tonma"
copyfile "Mr. HELI no Daibouken (Japan).mra" "_Mr. HELI no Daibouken"

symlinkfolder "_Gallop"
symlinkfolder "_Ninja Spirit"
symlinkfolder "_R-Type"

found=false
if  test -f "$RegSourceRoot/Image Fight (World).mra"; then
  copyfile "Image Fight (World).mra" "_Image Fight"
  found=true
fi
if  test -f "$RegSourceRoot/Image Fight (Japan).mra"; then
  copyfile "Image Fight (Japan).mra" "_Image Fight"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Image Fight"
else
rm -r "$ALT/_Image Fight" >/dev/null
fi

if  test -f "$RegSourceRoot/Dragon Breed (Japan).mra"; then
  copyfile "Dragon Breed (Japan).mra" "_Dragon Breed"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Dragon Breed"
else
rm -r "$ALT/_Image Fight" >/dev/null
fi

if  test -f "$RegSourceRoot/Legend of Hero Tonma (Japan).mra"; then
  copyfile "Legend of Hero Tonma (Japan).mra" "_Legend of Hero Tonma"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Legend of Hero Tonma"
else
rm -r "$ALT/_Legend of Hero Tonma" >/dev/null
fi

if  test -f "$RegSourceRoot/Mr. HELI no Daibouken (Japan).mra"; then
  copyfile "Mr. HELI no Daibouken (Japan).mra" "_Mr. HELI no Daibouken"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Mr. HELI no Daibouken"
else
rm -r "$ALT/_Mr. HELI no Daibouken" >/dev/null
fi

exit 0