 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M72 Hardware"

cd $OutputRoot

create "$MainDir"

copyfile "R-Type (Japan).mra" "_R-Type"
copyfile "R-Type (World).mra" "_R-Type"

symlinkfolder "_R-Type"
exit 0