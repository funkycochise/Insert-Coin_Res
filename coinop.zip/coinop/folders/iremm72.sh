 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M72 Hardware"

cd $OutputRoot

create "$MainDir"

copyfile "Gallop - Armed Police Unit (Japan).mra" "_Gallop"
copyfile "Ninja Spirit (Japan).mra" "_Ninja Spirit"
copyfile "R-Type (Japan).mra" "_R-Type"
copyfile "R-Type (World).mra" "_R-Type"

symlinkfolder "_Gallop"
symlinkfolder "_Ninja Spirit"
symlinkfolder "_R-Type"
exit 0