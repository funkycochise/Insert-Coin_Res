 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Technos"

cd $OutputRoot

create "$MainDir"

copyfile "Double Dragon.mra" "_Double Dragon"
copyfile "Double Dragon II - The Revenge.mra" "_Double Dragon II - The Revenge"
copyfile "V'Ball (US) [bl].mra" "_V'Ball"
copyfile "V'Ball (US).mra" "_V'Ball"
copyfile "Renegade (US bootleg).mra" "_Renegade"
copyfile "Nekketsu Kouha Kunio-kun (Japan bootleg).mra" "_Renegade"

symlinkfolder "_Double Dragon"
symlinkfolder "_Double Dragon II - The Revenge"
symlinkfolder "_V'Ball"
symlinkfolder "_Renegade"

exit 0