 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega"

cd $OutputRoot

create "$MainDir"

addgame "Future Spy.mra" "_Future Spy"
addgame "Pengo (Set 1, Rev C).mra" "_Pengo"
addgame "Super Zaxxon.mra" "_Super Zaxxon"
addgame "zaxxon.mra" "_Zaxxon"

exit 0