 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Bally-Midway"

cd $OutputRoot

create "$MainDir"

addgame "Crater Raider.mra" "_Crater Raider"
addgame "Demolition Derby (MCR-3 Mono Board Version).mra" "_Demolition Derby"
createlinkfile "Demolition Derby.mra" "_Demolition Derby"
addgame "Discs of Tron.mra" "_Disc of Tron"
addgame "Domino Man.mra" "_Domino Man"
addgame "Extra Bases.mra" "_Extra Bases"
addgame "Gorf (Program 1).mra" "_Gorf"
createlinkfile "Gorf (Speech).mra" "_Gorf"
createlinkfile "Gorf.mra" "_Gorf"
addgame "Journey.mra" "_Journey"
addgame "Kick.mra" "_Kick"
addgame "Kick-Man.mra" "_Kick-Man"
addgame "Kozmik Krooz'r.mra" "_Kozmik Kroozr"
addgame "Max RPM (v2).mra" "_Max RPM"
addgame "Max RPM.mra" "_Max RPM"
addgame "Ms. Pac-Man.mra" "_Ms.Pacman"
addgame "Pac-Man (Midway).mra" "_Pacman"
addgame "Pacman Plus.mra" "_Pacman Plus"
addgame "Power Drive.mra" "_Power Drive"
addgame "Rampage (Rev 3, 860827).mra" "_Rampage"
createlinkfile "Rampage.mra" "_Rampage"
addgame "Robby Roto.mra" "_Robby Roto"
addgame "Sarge.mra" "_Sarge"
addgame "Satans Hollow.mra" "_Satan's Hollow"
addgame "Sea Wolf (Set 1).mra" "_Sea Wolf"
addgame "Sea Wolf II.mra" "_Sea Wolf II"
createlinkfile "Sea Wolf.mra" "_Sea Wolf"
addgame "Solar Fox.mra" "_Solar Fox"
addgame "Space Invaders.mra" "_Space Invaders"
addgame "Space Zap.mra" "_Space Zap"
addgame "Spy Hunter.mra" "_Spy Hunter"
addgame "Star Guards.mra" "_Star Guards"
addgame "Tapper.mra" "_Tapper"
addgame "The Adventures of Robby Roto!.mra" "_Robby Roto"
addgame "Timber.mra" "_Timber"
addgame "Tron.mra" "_Tron"
addgame "Turbo Tag (Prototype).mra" "_Turbo Tag"
addgame "Turbo Tag.mra" "_Turbo Tag"
addgame "Two Tigers (Tron Conversion).mra" "_Two Tigers"
createlinkfile "Two Tigers.mra" "_Two Tigers"
addgame "Wacko.mra" "_Wacko"
addgame "Wizard of Wor (Speech).mra" "_Wizard of Wor"
createlinkfile "Wizard of Wor.mra" "_Wizard of Wor"

exit 0