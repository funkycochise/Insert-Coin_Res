 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Toaplan"

cd $OutputRoot

create "$MainDir"

addgame "Zero Wing (2P set).mra" "_Zero Wing"
addgame "Out Zone.mra" "_Out Zone"
addgame "Hellfire (2P set).mra" "_Hellfire"
addgame "Truxton - Tatsujin.mra" "_Truxton"
addgame "Truxton II - Tatsujin Oh.mra" "_Truxton II"
addgame "Snow Bros. 2 - With New Elves - Otenki Paradise (Hanafram).mra" "_Snow Bros. 2"

exit 0