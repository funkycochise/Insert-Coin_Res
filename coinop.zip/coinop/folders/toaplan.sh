 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Toaplan"

cd $OutputRoot

create "$MainDir"

copyfile "Zero Wing (2P set).mra" "_Zero Wing"
copyfile "Out Zone (Zero Wing TP-015 PCB conversion).mra" "_Out Zone"
copyfile "Out Zone.mra" "_Out Zone"
copyfile "Hellfire (2P set).mra" "_Hellfire"
copyfile "Truxton - Tatsujin.mra" "_Truxton"

symlinkfolder "_Out Zone"
symlinkfolder "_Zero Wing"
symlinkfolder "_Out Zone"
symlinkfolder "_Hellfire"
symlinkfolder "_Truxton"


exit 0