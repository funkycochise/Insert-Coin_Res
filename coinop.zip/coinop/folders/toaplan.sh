 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Toaplan"

cd $OutputRoot

create "$MainDir"

copyfile "Out Zone (Zero Wing TP-015 PCB conversion).mra" "_Out Zone"
copyfile "Zero Wing (2P set).mra" "_Zero Wing"

symlinkfolder "_Out Zone"
symlinkfolder "_Zero Wing"


exit 0