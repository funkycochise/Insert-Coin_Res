 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Toaplan"

cd $OutputRoot

create "$MainDir"

copyfile "Zero Wing (2P set).mra" "_Zero Wing"
copyfile "Out Zone.mra" "_Out Zone"
copyfile "Hellfire (2P set).mra" "_Hellfire"
copyfile "Truxton - Tatsujin.mra" "_Truxton"
copyfile "Truxton II - Tatsujin Oh.mra" "_Truxton2"
copyfile "Snow Bros. 2 - With New Elves - Otenki Paradise (Hanafram).mra" "_Snow Bros. 2"

symlinkfolder "_Zero Wing"
symlinkfolder "_Out Zone"
symlinkfolder "_Hellfire"
symlinkfolder "_Truxton"
symlinkfolder "_Truxton2"
symlinkfolder "_Snow Bros. 2"


exit 0