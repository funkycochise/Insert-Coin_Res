 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Toaplan"

cd $OutputRoot

create "$MainDir"

copyfile "Zero Wing (1P set).mra" "_Zero Wing"
copyfile "Zero Wing (2P set).mra" "_Zero Wing"
copyfile "Zero Wing (2P set, Williams license).mra" "_Zero Wing"

symlinkfolder "_Zero Wing"


exit 0