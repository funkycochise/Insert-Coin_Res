 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Tehkan-Tecmo"

cd $OutputRoot

create "$MainDir"

addgame "Argus no Senshi (Japan).mra" "_Rygar"
addgame "Bomb Jack.mra" "_Bomb Jack"
addgame "Gemini Wing.mra" "_Gemini Wing"
addgame "Pleiads (Centuri).mra" "_Pleiads"
addgame "Pleiads (Tehkan).mra" "_Pleiads"
addgame "Pleiads.mra" "_Pleiads"
addgame "Rygar (US set 2).mra" "_Rygar"
addgame "Rygar (US set 3 Old Version).mra" "_Rygar"
addgame "Rygar.mra" "_Rygar"
addgame "Silkworm.mra" "_Silkworm"
addgame "Solomon's Key.mra" "_Solomons Key"

exit 0