 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Robotron"

cd $OutputRoot

#create "$MainDir"

addgame "Alien Arena.mra" "_Robotron"
addgame "Bubbles.mra" "_Robotron"
addgame "Joust.mra" "_Robotron"
addgame "Playball.mra" "_Robotron"
addgame "Robotron 2084.mra" "_Robotron"
addgame "Sinistar.mra" "_Robotron"
addgame "Splat!.mra" "_Robotron"
addgame "Stargate.mra" "_Robotron"

exit 0