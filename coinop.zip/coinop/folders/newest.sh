 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

#echo "OutputRoot : $OutputRoot"
MainDir="__Newest"

cd $OutputRoot

create "$MainDir"

symlinkfolder "_R-Type"
symlinkfolder "_X Multiply"

found=false
if  test -f "$RegSourceRoot/chameleon.mra"; then
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Chameleon"
else
rm -r "$ALT/_Chameleon" >/dev/null
fi

symlinkfolder "_Dragon Breed"
symlinkfolder "_Final Fight AE"

found=false
if  test -f "$RegSourceRoot/Psychic 5 (World).mra"; then
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Psychic 5"
else
rm -r "$ALT/_Psychic 5" >/dev/null
fi

symlinkfolder "_Daiku no Gensan"
symlinkfolder "_Gallop"

found=false
if  test -f "$RegSourceRoot/Galivan.mra"; then
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Galivan"
else
rm -r "$ALT/_Galivan" >/dev/null
fi

symlinkfolder "_Air Duel"
symlinkfolder "_Legend of Hero Tonma"
symlinkfolder "_Ninja Spirit"
symlinkfolder "_Mr. HELI no Daibouken"
symlinkfolder "_Image Fight"

symlinkfolder "_Snow Bros. 2"

found=false
if  test -f "$RegSourceRoot/Prehistoric Isle in 1930 (World).mra"; then
  copyfile "Prehistoric Isle in 1930 (World).mra" "_Prehistoric Isle in 1930"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Prehistoric Isle in 1930"
else
  rm -r "$ALT/_Prehistoric Isle in 1930" >/dev/null
fi

exit 0