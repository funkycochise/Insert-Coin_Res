 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

#echo "OutputRoot : $OutputRoot"
MainDir="__Newest"

cd $OutputRoot

rm -r "/media/fat/_Arcade/$OutputRoot/$MainDir"
create "$MainDir"

#1009
if  test -f "$RegSourceRoot/Karate Champ (US).mra"; then
  symlinkfolder "_Karate Champ"
fi
#1009
symlinkfolder "_R-Type II"
#0509
symlinkfolder "_Snow Bros. 2"
#0409
if  test -f "$RegSourceRoot/Galivan.mra"; then
  symlinkfolder "_Galivan"
fi
#0109
symlinkfolder "_Daiku no Gensan"
0109
symlinkfolder "_Final Fight AE"
#3008
symlinkfolder "_Air Duel"
#3008
symlinkfolder "_X Multiply"
#2708
if  test -f "$RegSourceRoot/Prehistoric Isle in 1930 (World).mra"; then
   symlinkfolder "_Prehistoric Isle in 1930"
fi
#2508
symlinkfolder "_Mr. HELI no Daibouken"
#2508
symlinkfolder "_Legend of Hero Tonma"
#2508
symlinkfolder "_Dragon Breed"

#2208
if  test -f "$RegSourceRoot/chameleon.mra"; then
  symlinkfolder "_Chameleon"
fi
#1608
symlinkfolder "_Gallop"
#1608
symlinkfolder "_Image Fight"
#1608
symlinkfolder "_Ninja Spirit"
#2407
#symlinkfolder "_R-Type"
#0207
if  test -f "$RegSourceRoot/Psychic 5 (World).mra"; then
  symlinkfolder "_Psychic 5"
fi



exit 0