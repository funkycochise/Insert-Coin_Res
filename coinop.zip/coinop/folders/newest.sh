 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

#echo "OutputRoot : $OutputRoot"
MainDir="__Newest"

cd $OutputRoot

create "$MainDir"

symlinkfolder "_Final Fight AE"
symlinkfolder "_Daiku no Gensan"
symlinkfolder "_X Multiply"
symlinkfolder "_Missile_Command"
symlinkfolder "_Air Duel"
symlinkfolder "_Dragon Breed"
symlinkfolder "_Gallop"
symlinkfolder "_Image Fight"
symlinkfolder "_Legend of Hero Tonma"
symlinkfolder "_Mr. HELI no Daibouken"
symlinkfolder "_Ninja Spirit"
symlinkfolder "_R-Type"
symlinkfolder "_Snow Bros. 2"

found=false
if  test -f "$RegSourceRoot/Prehistoric Isle in 1930 (World).mra"; then
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Prehistoric Isle in 1930"
else
  rm -r "$ALT/_Prehistoric Isle in 1930" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Psychic 5 (World).mra"; then
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Psychic 5"
else
rm -r "$ALT/_Psychic 5" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/chameleon.mra"; then
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Chameleon"
else
rm -r "$ALT/_Chameleon" >/dev/null
fi

exit 0