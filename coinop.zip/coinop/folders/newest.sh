#!/bin/bash
#exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null 

source ./folders/functions.sh

OutputRoot=$1
RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives
RegSourceRoot=/media/fat/_Arcade

#echo "OutputRoot : $OutputRoot"
MainDir="__Newest"

cd $OutputRoot

rm -r "/media/fat/_Arcade/$OutputRoot/$MainDir"
create "$MainDir"

counter=0

function linkfolder {
   counter=$((counter+1))
   if [[ "$counter" -lt 17 ]]; then
      special_echo "$counter - $1"
      ln -s "$ALT/$1"  "$OutputRoot/$MainDir/$1"
   fi
}

#1009
if  test -f "$RegSourceRoot/Ufo Robo Dangar (4-07-1987).mra"; then
  linkfolder "_Ufo Robo Dangar"
fi

#1009
if  test -f "$RegSourceRoot/Karate Champ (US).mra"; then
  linkfolder "_Karate Champ"
fi
#1009
linkfolder "_R-Type II"
#0509
linkfolder "_Snow Bros. 2"
#0409
if  test -f "$RegSourceRoot/Cosmo Police Galivan (12-26-1985).mra"; then
  linkfolder "_Galivan"
fi
#0109
linkfolder "_Hammerin' Harry"
0109
linkfolder "_Final Fight AE"
#3008
linkfolder "_Air Duel"
#3008
linkfolder "_X Multiply"
#2708
if  test -f "$RegSourceRoot/Prehistoric Isle in 1930 (World).mra"; then
   linkfolder "_Prehistoric Isle in 1930"
fi
#2508
linkfolder "_Mr. HELI no Daibouken"
#2508
linkfolder "_Legend of Hero Tonma"
#2508
linkfolder "_Dragon Breed"

#2208
if  test -f "$RegSourceRoot/chameleon.mra"; then
  linkfolder "_Chameleon"
fi
#1608
linkfolder "_Gallop"
#1608
linkfolder "_Image Fight"
#1608
linkfolder "_Ninja Spirit"
#2407
#linkfolder "_R-Type"
#0207
if  test -f "$RegSourceRoot/Psychic 5 (World).mra"; then
  linkfolder "_Psychic 5"
fi



exit 0