 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Cave68K"

cd $OutputRoot

create "$MainDir"

copyfile "Dangun Feveron.mra" "_Dangun Feveron"
copyfile "DonPachi.mra" "_DonPachi"
copyfile "DonPachi (Japan).mra" "_DonPachi"
copyfile "DoDonPachi (Arrange).mra" "_DoDonPachi"
copyfile "DoDonPachi (Japan).mra" "_DoDonPachi"
copyfile "DoDonPachi Trainer (Japan).mra" "_DoDonPachi"
copyfile "DoDonPachi.mra" "_DoDonPachi"
copyfile "ESP Ra.De..mra" "_ESP Ra.De."
copyfile "Fever SOS.mra" "_Dangun Feveron"
copyfile "Puzzle Uo Poko.mra" "_Puzzle Uo Poko"
copyfile "Puzzle Uo Poko (Japan).mra" "_Puzzle Uo Poko"
copyfile "Guwange.mra" "_Guwange"
copyfile "Guwange (Special).mra" "_Guwange"
copyfile "Gaia Crusaders.mra" "_Gaia Crusaders"
copyfile "Thunder Heroes.mra" "_Thunder Heroes"

found=false
if  test -f "$RegSourceRoot/Hotdog Storm.mra"; then
  copyfile "Hotdog Storm.mra" "_Hotdog Storm"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Hotdog Storm"
else
  rm -r "$ALT/_Hotdog Storm" >/dev/null
fi

#symlinkfolder "$MainDir"
symlinkfolder "_Dangun Feveron"
symlinkfolder "_DonPachi"
symlinkfolder "_DoDonPachi"
symlinkfolder "_ESP Ra.De."
symlinkfolder "_Puzzle Uo Poko"
symlinkfolder "_Guwange"
symlinkfolder "_Gaia Crusaders"
symlinkfolder "_Thunder Heroes"

exit 0