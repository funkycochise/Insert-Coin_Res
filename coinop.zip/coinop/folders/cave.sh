 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Cave68K"

cd $OutputRoot

create "$MainDir"

copyfile "Dangun Feveron.mra" "$MainDir"
copyfile "DonPachi.mra" "$MainDir"
copyfile "DonPachi (Japan).mra" "$MainDir"
copyfile "DoDonPachi (Arrange).mra" "$MainDir"
copyfile "DoDonPachi (Japan).mra" "$MainDir"
copyfile "DoDonPachi Trainer (Japan).mra" "$MainDir"
copyfile "DoDonPachi.mra" "$MainDir"
copyfile "ESP Ra.De..mra" "$MainDir"
copyfile "Fever SOS.mra" "$MainDir"
copyfile "Puzzle Uo Poko.mra" "$MainDir"
copyfile "Puzzle Uo Poko (Japan).mra" "$MainDir"
copyfile "Guwange.mra" "$MainDir"
copyfile "Guwange (Special).mra" "$MainDir"
copyfile "DonPachi.mra" "$MainDir"
copyfile "Gaia Crusaders.mra" "$MainDir"
copyfile "Thunder Heroes.mra" "$MainDir"

symlinkfolder "$MainDir"

exit 0