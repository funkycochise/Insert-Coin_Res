 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Cave68K"

cd $OutputRoot

create "$MainDir"

found=false
if  test -f "$RegSourceRoot/Dangun Feveron.mra"; then
  copyfile "Dangun Feveron.mra" "_Dangun Feveron"
  found=true
fi
if  test -f "$RegSourceRoot/Fever SOS.mra"; then
  copyfile "Fever SOS.mra" "_Dangun Feveron"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Dangun Feveron"
else
  rm -r "$ALT/_Dangun Feveron" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/DoDonPachi (Arrange).mra"; then
  copyfile "DoDonPachi (Arrange).mra" "_DoDonPachi"
  found=true
fi
if  test -f "$RegSourceRoot/DoDonPachi (Japan).mra"; then
  copyfile "DoDonPachi (Japan).mra" "_DoDonPachi"
  found=true
fi
if  test -f "$RegSourceRoot/DoDonPachi (Japan, No Warn).mra"; then
  copyfile "DoDonPachi (Japan, No Warn).mra" "_DoDonPachi"
  found=true
fi
if  test -f "$RegSourceRoot/DoDonPachi Trainer (Japan).mra"; then
  copyfile "DoDonPachi Trainer (Japan).mra" "_DoDonPachi"
  found=true
fi
if  test -f "$RegSourceRoot/DoDonPachi.mra"; then
  copyfile "DoDonPachi.mra" "_DoDonPachi"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_DoDonPachi"
else
  rm -r "$ALT/_DoDonPachi">/dev/null
fi

found=false
if  test -f "$RegSourceRoot/ESP Ra.De..mra"; then
  copyfile "ESP Ra.De..mra" "_ESP Ra.De"
  found=true
fi
if  test -f "$RegSourceRoot/ESP Ra.De. (Japan).mra"; then
  copyfile "ESP Ra.De. (Japan).mra" "_ESP Ra.De"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_ESP Ra.De"
else
  rm -r "$ALT/_ESP Ra.De">/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Gaia Crusaders.mra"; then
  copyfile "Gaia Crusaders.mra" "_Gaia Crusaders"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Gaia Crusaders"
else
  rm -r "$ALT/_Gaia Crusaders" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Guwange.mra"; then
  copyfile "Guwange.mra" "_Guwange"
  found=true
fi
if  test -f "$RegSourceRoot/Guwange (Special).mra"; then
  copyfile "Guwange (Special).mra" "_Guwange"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Guwange"
else
  rm -r "$ALT/_Guwange">/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Hotdog Storm.mra"; then
  copyfile "Hotdog Storm.mra" "_Hotdog Storm"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Hotdog Storm"
else
  rm -r "$ALT/_Hotdog Storm" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Puzzle Uo Poko.mra"; then
  copyfile "Puzzle Uo Poko.mra" "_Puzzle Uo Poko"
  found=true
fi
if  test -f "$RegSourceRoot/Puzzle Uo Poko (Japan).mra"; then
  copyfile "Puzzle Uo Poko (Japan).mra" "_Puzzle Uo Poko"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Puzzle Uo Poko"
else
  rm -r "$ALT/_Puzzle Uo Poko">/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Thunder Heroes.mra"; then
  copyfile "Thunder Heroes.mra" "_Thunder Heroes"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Thunder Heroes"
else
  rm -r "$ALT/_Thunder Heroes" >/dev/null
fi


exit 0