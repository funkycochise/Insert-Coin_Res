 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Cave68K"

cd $OutputRoot

create "$MainDir"


  addgame "Dangun Feveron.mra" "_Dangun Feveron"
  createlinkfile "Fever SOS.mra" "_Dangun Feveron"
  addgame "DoDonPachi (Arrange).mra" "_DoDonPachi"
  createlinkfile "DoDonPachi (Japan).mra" "_DoDonPachi"
  createlinkfile "DoDonPachi (Japan, No Warn).mra" "_DoDonPachi"
  createlinkfile "DoDonPachi Trainer (Japan).mra" "_DoDonPachi"
  createlinkfile "DoDonPachi.mra" "_DoDonPachi"
  addgame "DonPachi.mra" "_DonPachi"
  createlinkfile "DonPachi (Japan).mra" "_DonPachi"
  addgame "ESP Ra.De..mra" "_ESP Ra.De"
  createlinkfile "ESP Ra.De. (Japan).mra" "_ESP Ra.De"
  addgame "Gaia Crusaders.mra" "_Gaia Crusaders"
  addgame "Guwange.mra" "_Guwange"
  createlinkfile "Guwange (Special).mra" "_Guwange"
  addgame "Hotdog Storm.mra" "_Hotdog Storm"
  addgame "Puzzle Uo Poko.mra" "_Puzzle Uo Poko"
  createlinkfile "Puzzle Uo Poko (Japan).mra" "_Puzzle Uo Poko"
  addgame "Thunder Heroes.mra" "_Thunder Heroes"

exit 0