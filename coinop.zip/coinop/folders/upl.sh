 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Upl"

cd $OutputRoot

create "$MainDir"

addgame "Ninjakun.mra" "_Ninjakun Majou no Bouken"
addgame "Penguin-Kun Wars.mra" "_Penguin-Kun Wars"
addgame "Penguin-Kun Wars (Japan).mra" "_Penguin-Kun Wars"

exit 0