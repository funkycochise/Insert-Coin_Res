 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Upl"

cd $OutputRoot

create "$MainDir"

orientation=$2

#if [ -z "$orientation" ] || [ "$orientation" = "V" ];
#then
#   #special_echo "\$orientation is empty or V"
#fi
if [ -z "$orientation" ] || [ "$orientation" = "H" ];
then
   #special_echo "\$orientation is empty or H"
   addgame "Ninjakun.mra" "_Ninjakun Majou no Bouken"
   addgame "Penguin-Kun Wars.mra" "_Penguin-Kun Wars"
   addgame "Penguin-Kun Wars (Japan).mra" "_Penguin-Kun Wars"
fi
exit 0