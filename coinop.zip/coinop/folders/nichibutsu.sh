 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nichibutsu"

cd $OutputRoot

create "$MainDir"

copyfile "Crazy Climber.mra" "_Crazy Climber"
copyfile "Moon Cresta.mra" "_Moon Cresta"

symlinkfolder "_Crazy Climber"
symlinkfolder "_Moon Cresta"

exit 0