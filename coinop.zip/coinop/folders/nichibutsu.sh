 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nichibutsu"

cd $OutputRoot

create "$MainDir"

copyfile "Armed F (Japan).mra" "_Formation Armed F"
copyfile "Crazy Climber 2 (Japan).mra" "_Crazy Climber 2"
copyfile "Crazy Climber.mra" "_Crazy Climber"
copyfile "Kid no Hore Hore Daisakusen.mra" "_Booby Kids"
copyfile "Kozure Ookami (Japan).mra" "_Kozure Ookami"
copyfile "Legion - Spinner-87 (World ver 2.03).mra" "_Legion - Spinner-87"
copyfile "Moon Cresta.mra" "_Moon Cresta"
copyfile "Tatakae! Big Fighter (Japan).mra" "_Sky Robo"
copyfile "Sei Senshi Amatelass.mra" "_Soldier Girl Amazon"
copyfile "Terra Cresta (YM3526 set 1).mra" "_Terra Cresta"

symlinkfolder "_Booby Kids"
symlinkfolder "_Crazy Climber"
symlinkfolder "_Crazy Climber 2"
symlinkfolder "_Formation Armed F"
symlinkfolder "_Kozure Ookami"
symlinkfolder "_Legion - Spinner-87"
symlinkfolder "_Moon Cresta"
symlinkfolder "_Sky Robo"
symlinkfolder "_Soldier Girl Amazon"
symlinkfolder "_Terra Cresta"


exit 0