 #!/bin/bash  

source ./folders/functions.sh

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nichibutsu"

cd $OutputRoot

create "$MainDir"

addsingle "Kid no Hore Hore Daisakusen.mra" "_Booby Kids"
addsingle "Crazy Climber.mra" "_Crazy Climber"
addsingle "Crazy Climber 2 (Japan).mra" "_Crazy Climber 2"
addsingle "Armed F (Japan).mra" "_Formation Armed F"
addsingle "Cosmo Police Galivan (12-26-1985).mra" "_Galivan"
addsingle "Kozure Ookami (Japan).mra" "_Kozure Ookami"
addsingle "Legion - Spinner-87 (World ver 2.03).mra" "_Legion - Spinner-87"
addsingle "Moon Cresta.mra" "_Moon Cresta"
addsingle "Sei Senshi Amatelass.mra" "_Soldier Girl Amazon"
addsingle "Tatakae! Big Fighter (Japan).mra" "_Sky Robo"
addsingle "Terra Cresta (YM3526 set 1).mra" "_Terra Cresta"
addsingle "Terra Force (Japan).mra" "_Terra Force"
addsingle "Ufo Robo Dangar (4-07-1987).mra" "_Ufo Robo Dangar"


exit 0