 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nichibutsu"

cd $OutputRoot

create "$MainDir"

copyfile "Armed F (Japan).mra" "_Formation Armed F"
copyfile "Crazy Climber.mra" "_Crazy Climber"
copyfile "Kid no Hore Hore Daisakusen.mra" "_Booby Kids"
copyfile "Kozure Ookami (Japan).mra" "_Kozure Ookami"
copyfile "legion.zip" "_Legion"
copyfile "Moon Cresta.mra" "_Moon Cresta"
copyfile "Sei Senshi Amatelass.mra" "_Soldier Girl Amazon"
copyfile "Terra Cresta (YM3526 set 1).mra" "_Terra Cresta"

symlinkfolder "_Booby Kids"
symlinkfolder "_Crazy Climber"
symlinkfolder "_Formation Armed F"
symlinkfolder "_Kozure Ookami"
symlinkfolder "_Legion"
symlinkfolder "_Moon Cresta"
symlinkfolder "_Soldier Girl Amazon"
symlinkfolder "_Terra Cresta"


exit 0