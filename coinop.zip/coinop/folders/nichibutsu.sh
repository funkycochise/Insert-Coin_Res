 #!/bin/bash  

source ./folders/functions.sh

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nichibutsu"

cd $OutputRoot

create "$MainDir"

createlinkfile "Armed F (Japan).mra" "_Formation Armed F"
createlinkfile "Crazy Climber 2 (Japan).mra" "_Crazy Climber 2"
createlinkfile "Crazy Climber.mra" "_Crazy Climber"
createlinkfile "Kid no Hore Hore Daisakusen.mra" "_Booby Kids"
createlinkfile "Kozure Ookami (Japan).mra" "_Kozure Ookami"
createlinkfile "Legion - Spinner-87 (World ver 2.03).mra" "_Legion - Spinner-87"
createlinkfile "Moon Cresta.mra" "_Moon Cresta"
createlinkfile "Tatakae! Big Fighter (Japan).mra" "_Sky Robo"
createlinkfile "Sei Senshi Amatelass.mra" "_Soldier Girl Amazon"
createlinkfile "Terra Cresta (YM3526 set 1).mra" "_Terra Cresta"
createlinkfile "Terra Force (Japan).mra" "_Terra Force"

symlinkfolder "_Booby Kids"
symlinkfolder "_Crazy Climber"
symlinkfolder "_Crazy Climber 2"
symlinkfolder "_Formation Armed F"
symlinkfolder "_Kozure Ookami"
symlinkfolder "_Legion - Spinner-87"
symlinkfolder "_Moon Cresta"
symlinkfolder "_Sky Robo"
symlinkfolder "_Soldier Girl Amazon"
symlinkfolder "_Terra Cresta"
symlinkfolder "_Terra Force"

if  test -f "$RegSourceRoot/Cosmo Police Galivan (12-26-1985).mra"; then
  symlinkfolder "_Galivan"
fi
if  test -f "$RegSourceRoot/Ufo Robo Dangar (4-07-1987).mra"; then
  symlinkfolder "_Ufo Robo Dangar"
fi


exit 0