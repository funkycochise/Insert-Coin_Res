 #!/bin/bash  

source ./folders/functions.sh

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nichibutsu"

cd $OutputRoot

create "$MainDir"

if  test -f "$RegSourceRoot/Armed F (Japan).mra"; then
   createlinkfile "Armed F (Japan).mra" "_Formation Armed F"
   symlinkfolder "_Formation Armed F"
fi
if  test -f "$RegSourceRoot/Crazy Climber.mra"; then
   createlinkfile "Crazy Climber.mra" "_Crazy Climber"
   symlinkfolder "_Crazy Climber"
fi
if  test -f "$RegSourceRoot/Crazy Climber 2 (Japan).mra"; then
   createlinkfile "Crazy Climber 2 (Japan).mra" "_Crazy Climber 2"
   symlinkfolder "_Crazy Climber 2"
fi
if  test -f "$RegSourceRoot/Kid no Hore Hore Daisakusen.mra"; then
   createlinkfile "Kid no Hore Hore Daisakusen.mra" "_Booby Kids"
   symlinkfolder "_Booby Kids"
fi
if  test -f "$RegSourceRoot/Kozure Ookami (Japan).mra"; then
   createlinkfile "Kozure Ookami (Japan).mra" "_Kozure Ookami"
   symlinkfolder "_Kozure Ookami"
fi
if  test -f "$RegSourceRoot/Legion - Spinner-87 (World ver 2.03).mra"; then
   createlinkfile "Legion - Spinner-87 (World ver 2.03).mra" "_Legion - Spinner-87"
   symlinkfolder "_Legion - Spinner-87"
fi
if  test -f "$RegSourceRoot/Moon Cresta.mra"; then
   createlinkfile "Moon Cresta.mra" "_Moon Cresta"
   symlinkfolder "_Moon Cresta"
fi
if  test -f "$RegSourceRoot/Sei Senshi Amatelass.mra"; then
   createlinkfile "Sei Senshi Amatelass.mra" "_Soldier Girl Amazon"
   symlinkfolder "_Soldier Girl Amazon"
fi
if  test -f "$RegSourceRoot/Tatakae! Big Fighter (Japan).mra"; then
   createlinkfile "Tatakae! Big Fighter (Japan).mra" "_Sky Robo"
   symlinkfolder "_Sky Robo"
fi
if  test -f "$RegSourceRoot/Terra Cresta (YM3526 set 1).mra"; then
   createlinkfile "Terra Cresta (YM3526 set 1).mra" "_Terra Cresta"
   symlinkfolder "_Terra Cresta"
fi
if  test -f "$RegSourceRoot/Terra Force (Japan).mra"; then
   createlinkfile "Terra Force (Japan).mra" "_Terra Force"
   symlinkfolder "_Terra Force"
fi

if  test -f "$RegSourceRoot/Cosmo Police Galivan (12-26-1985).mra"; then
   createlinkfile "Cosmo Police Galivan (12-26-1985).mra" "_Galivan"
   symlinkfolder "_Galivan"
fi
if  test -f "$RegSourceRoot/Ufo Robo Dangar (4-07-1987).mra"; then
   createlinkfile "Ufo Robo Dangar (4-07-1987).mra" "_Ufo Robo Dangar"
   symlinkfolder "_Ufo Robo Dangar"
fi


exit 0