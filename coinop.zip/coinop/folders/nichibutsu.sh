 #!/bin/bash  

source ./folders/functions.sh

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nichibutsu"

cd $OutputRoot

create "$MainDir"

copyfile "Armed F (Japan).mra" "_Formation Armed F"
copyfile "Crazy Climber 2 (Japan).mra" "_Crazy Climber 2"
copyfile "Crazy Climber.mra" "_Crazy Climber"
copyfile "Kid no Hore Hore Daisakusen.mra" "_Booby Kids"
copyfile "Kozure Ookami (Japan).mra" "_Kozure Ookami"
copyfile "Legion - Spinner-87 (World ver 2.03).mra" "_Legion - Spinner-87"
copyfile "Moon Cresta.mra" "_Moon Cresta"
copyfile "Tatakae! Big Fighter (Japan).mra" "_Sky Robo"
copyfile "Sei Senshi Amatelass.mra" "_Soldier Girl Amazon"
copyfile "Terra Cresta (YM3526 set 1).mra" "_Terra Cresta"
copyfile "Terra Force (Japan).mra" "_Terra Force"

symlinkfolder "_Booby Kids"
symlinkfolder "_Crazy Climber"
symlinkfolder "_Crazy Climber 2"
symlinkfolder "_Formation Armed F"
symlinkfolder "_Kozure Ookami"
symlinkfolder "_Legion - Spinner-87"
symlinkfolder "_Moon Cresta"
symlinkfolder "_Sky Robo"
symlinkfolder "_Soldier Girl Amazon"
symlinkfolder "_Terra Cresta"
symlinkfolder "_Terra Force"

found=false
if  test -f "$RegSourceRoot/Cosmo Police Galivan (12-26-1985).mra"; then
  copyfile "Galivan.mra" "_Galivan"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Galivan"
else
  rm -r "$ALT/_Galivan" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Ufo Robo Dangar (4-07-1987).mra"; then
  copyfile "Ufo Robo Dangar (4-07-1987).mra" "_Ufo Robo Dangar"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Ufo Robo Dangar"
else
  rm -r "$ALT/_Galivan" >/dev/null
fi


exit 0