 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nichibutsu"

cd $OutputRoot

create "$MainDir"

copyfile "Crazy Climber.mra" "_Crazy Climber"
copyfile "Moon Cresta.mra" "_Moon Cresta"
copyfile "Terra Cresta (YM3526 set 1).mra" "_Terra Cresta"

symlinkfolder "_Crazy Climber"
symlinkfolder "_Moon Cresta"
symlinkfolder "_Terra Cresta"

exit 0