 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega-System1"

cd $OutputRoot

create "$MainDir"

createreplacefolder "_4D Warriors"
createreplacefolder "_Block Gal"
createreplacefolder "_Bullfight"
createreplacefolder "_Flicky"
createreplacefolder "_I'm sorry"
createreplacefolder "_Mister Viking"
createreplacefolder "_Noboranka"

copyfile "4D Warriors (315-5162).mra" "_4D Warriors"
copyfile "Block Gal [MC-8123B, 317-0029].mra" "_Block Gal"
copyfile "Bullfight (World, 315-5065).mra" "_Bullfight"
copyfile "Flicky (128k Version, 315-5051).mra" "_Flicky"
copyfile "Gardia (317-0006).mra" "_Gardia"
copyfile "Gonbee no I'm Sorry (315-5110, Japan).mra" "_I'm sorry"
copyfile "I'm Sorry (US, 315-5110).mra" "_I'm sorry"
copyfile "Mister Viking (Japan, 315-5041).mra" "_Mister Viking"
copyfile "Mister Viking (World, 315-5041).mra" "_Mister Viking"
copyfile "My Hero (US, not Encrypted).mra" "_My Hero"
copyfile "Noboranka (bootleg).mra" "_Noboranka"
copyfile "Pitfall II (World, 315-5093).mra" "_Pitfall II"
copyfile "Rafflesia (315-5162).mra" "_Rafflesia"
copyfile "Regulus (World, 315-5033, Rev A.).mra" "_Regulus"
copyfile "Sega Ninja (315-5102).mra" "_Sega Ninja"
copyfile "Spatter (World, 315-5xxx).mra" "_Spatter"
copyfile "Star Jacker (alt).mra" "_Star Jacker"
copyfile "Star Jacker.mra" "_Star Jacker"
copyfile "SWAT (World, 315-5048).mra" "_Swat"
copyfile "TeddyBoy Blues (World, 315-5115, New Ver.).mra" "_TeddyBoy Blues"
copyfile "Up'n Down (World, 315-5030).mra" "_Up'n Down"
copyfile "Water Match (World, 315-5064).mra" "_Water Match"
copyfile "Wonder Boy (Set 1, 315-5177).mra" "_Wonder Boy"

symlinkfolder "_4D Warriors"
symlinkfolder "_Block Gal"
symlinkfolder "_Bullfight"
symlinkfolder "_Flicky"
symlinkfolder "_Gardia"
symlinkfolder "_I'm sorry"
symlinkfolder "_Mister Viking"
symlinkfolder "_My Hero"
symlinkfolder "_Noboranka"
symlinkfolder "_Pitfall II"
symlinkfolder "_Rafflesia"
symlinkfolder "_Regulus"
symlinkfolder "_Sega Ninja"
symlinkfolder "_Spatter"
symlinkfolder "_Star Jacker"
symlinkfolder "_Swat"
symlinkfolder "_TeddyBoy Blues"
symlinkfolder "_Up'n Down"
symlinkfolder "_Water Match"
symlinkfolder "_Wonder Boy"

exit 0