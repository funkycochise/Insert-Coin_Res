 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega-System1"

cd $OutputRoot

create "$MainDir"

createreplacefolder "_4D Warriors"
createreplacefolder "_Block Gal"
createreplacefolder "_Bullfight"
createreplacefolder "_Flicky"
createreplacefolder "_I'm sorry"
createreplacefolder "_Mister Viking"
createreplacefolder "_Noboranka"

orientation=$2

if [ -z "$orientation" ] || [ "$orientation" = "V" ];
then
   #special_echo "\$orientation is empty or V"
   addgame "Gardia (317-0006).mra" "_Gardia"
   addgame "Noboranka (bootleg).mra" "_Noboranka"
   addgame "Regulus (World, 315-5033, Rev A.).mra" "_Regulus"
   addgame "Sega Ninja (315-5102).mra" "_Sega Ninja"
   addgame "Up'n Down (World, 315-5030).mra" "_Up'n Down"
fi
if [ -z "$orientation" ] || [ "$orientation" = "H" ];
then
   #special_echo "\$orientation is empty or H"
   addgame "4D Warriors (315-5162).mra" "_4D Warriors"
   addgame "Block Gal [MC-8123B, 317-0029].mra" "_Block Gal"
   addgame "Bullfight (World, 315-5065).mra" "_Bullfight"
   addgame "Flicky (128k Version, 315-5051).mra" "_Flicky"
   addgame "Gonbee no I'm Sorry (315-5110, Japan).mra" "_I'm sorry"
   addgame "I'm Sorry (US, 315-5110).mra" "_I'm sorry"
   addgame "Mister Viking (Japan, 315-5041).mra" "_Mister Viking"
   addgame "Mister Viking (World, 315-5041).mra" "_Mister Viking"
   addgame "My Hero (US, not Encrypted).mra" "_My Hero"
   addgame "Pitfall II (World, 315-5093).mra" "_Pitfall II"
   addgame "Rafflesia (315-5162).mra" "_Rafflesia"
   addgame "Spatter (World, 315-5xxx).mra" "_Spatter"
   addgame "Star Jacker (alt).mra" "_Star Jacker"
   addgame "Star Jacker.mra" "_Star Jacker"
   addgame "SWAT (World, 315-5048).mra" "_Swat"
   addgame "TeddyBoy Blues (World, 315-5115, New Ver.).mra" "_TeddyBoy Blues"
   addgame "Water Match (World, 315-5064).mra" "_Water Match"
   addgame "Wonder Boy (Set 1, 315-5177).mra" "_Wonder Boy"
fi
exit 0