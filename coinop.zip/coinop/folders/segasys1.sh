 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega-System1"

cd $OutputRoot

create "$MainDir"

copyfile "4D Warriors (315-5162).mra" "_4D Warriors"
copyfile "Flicky (128k Version, 315-5051).mra" "_Flicky"
copyfile "Gardia (317-0006).mra" "_Gardia"
copyfile "My Hero (US, not Encrypted).mra" "_My Hero"
copyfile "Noboranka (bootleg).mra" "_Noboranka"
copyfile "Rafflesia (315-5162).mra" "_Rafflesia"
copyfile "Sega Ninja (315-5102).mra" "_Sega Ninja"
copyfile "Star Jacker.mra" "_Star Jacker"
copyfile "Star Jacker (alt).mra" "_Star Jacker"
copyfile "TeddyBoy Blues (World, 315-5115, New Ver.).mra" "_TeddyBoy Blues"
copyfile "Wonder Boy (Set 1, 315-5177).mra" "_Wonder Boy"

symlinkfolder "_4D Warriors"
symlinkfolder "_Flicky"
symlinkfolder "_Gardia"
symlinkfolder "_My Hero"
symlinkfolder "_Noboranka"
symlinkfolder "_Rafflesia"
symlinkfolder "_Sega Ninja"
symlinkfolder "_Star Jacker"
symlinkfolder "_TeddyBoy Blues"
symlinkfolder "_Wonder Boy"

copyfile "Block Gal.mra" "_Block Gal"
copyfile "Bullfight.mra" "_Bullfight"
copyfile "I'm Sorry.mra" "_I'm sorry"
copyfile "Mister Viking (315-5041).mra" "_Mister Viking"
copyfile "Mister Viking (315-5041, Japan).mra" "_Mister Viking"
copyfile "Pitfall II.mra" "_Pitfall II"
copyfile "Regulus.mra" "_Regulus"
copyfile "Spatter.mra" "_Spatter"
copyfile "Swat.mra" "_Swat"
copyfile "Up'n Down.mra" "_Up'n Down"
copyfile "Water Match.mra" "_Water Match"
copyfile "Water Match (315-5064).mra" "_Water Match"

symlinkfolder "_Block Gal"
symlinkfolder "_Bullfight"
symlinkfolder "_I'm sorry"
symlinkfolder "_Mister Viking"
symlinkfolder "_Pitfall II"
symlinkfolder "_Regulus"
symlinkfolder "_Spatter"
symlinkfolder "_Swat"
symlinkfolder "_Up'n Down"
symlinkfolder "_Water Match"


exit 0