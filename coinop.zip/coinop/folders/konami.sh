 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Konami"

cd $OutputRoot

create "$MainDir"

copyfile "Amidar.mra" "_Amidar"
copyfile "Amidar (Scramble).mra" "_Amidar"
copyfile "Combat School Joystick.mra" "_Combat School"
copyfile "Frogger.mra" "_Frogger"
copyfile "Frogger (Konami Bugfixed).mra" "_Frogger"
copyfile "Frogger (Sega, Set 2).mra" "_Frogger"
copyfile "Green Beret.mra" "_Green Beret"
copyfile "Rush'n Attack (US).mra" "_Green Beret"
copyfile "Gyruss.mra" "_Gyruss"
copyfile "Venus (bootleg of Gyruss).mra" "_Gyruss"
copyfile "Gyruss (bootleg).mra" "_Gyruss"
copyfile "Gyruss (Centuri).mra" "_Gyruss"
copyfile "Gyruss.mra" "_Gyruss"
copyfile "Pooyan.mra" "_Pooyan"
copyfile "River Patrol.mra" "_River Patrol"
copyfile "River Patrol (JP, Unprotected).mra" "_River Patrol"
copyfile "Scramble.mra" "_Scramble"
copyfile "Scramble (Stern, Set 1).mra" "_Scramble"
copyfile "Super Cobra.mra" "_Super Cobra"
copyfile "The End.mra" "_The End"
copyfile "The End (bkg).mra" "_The End"
copyfile "Time Pilot '84 (Set 1).mra" "_Time Pilot 84"
copyfile "Time Pilot '84 (Set 2).mra" "_Time Pilot 84"
copyfile "Time Pilot '84 (Set 3).mra" "_Time Pilot 84"
copyfile "Time Pilot.mra" "_Time Pilot"
copyfile "Trick Trap (World).mra" "_Labyrinth Runner"
copyfile "Mr. Goemon.mra" "_Mr. Goemon"
copyfile "Jailbreak.mra" "_JailBreak"
copyfile "Manhattan 24 Bunsyo (J).mra" "_JailBreak"
copyfile "Iron Horse (Ver. K).mra" "_Iron Horse"
copyfile "Jackal (W).mra" "_Jackal"
copyfile "Jackal (W) [bl].mra" "_Jackal"
copyfile "Top Gunner (US) [bl].mra" "_Jackal"
copyfile "Tokushu Butai Jackal (JP).mra" "_Jackal"
copyfile "Jackal (W, Rotary).mra" "_Jackal"
copyfile "Top Gunner (US).mra" "_Jackal"
copyfile "MX5000.mra" "_MX5000"
copyfile "Fast Lane.mra" "_Fast Lane"
copyfile "Scooter Shooter.mra" "_Scooter Shooter"
copyfile "Finalizer - Super Transformation (Set 1).mra" "_Finalizer - Super Transformation"
copyfile "Finalizer - Super Transformation (Set 2).mra" "_Finalizer - Super Transformation"
copyfile "Finalizer - Super Transformation (Set 2) [bl].mra" "_Finalizer - Super Transformation"
copyfile "Kicker.mra" "_Kicker"
copyfile "Yie Ar Kung-Fu (program code I).mra" "_Yie Ar Kung-Fu"

symlinkfolder "_Amidar"
symlinkfolder "_Combat School"
symlinkfolder "_Contra"
symlinkfolder "_Frogger"
symlinkfolder "_Green Beret"
symlinkfolder "_Gyruss"
symlinkfolder "_Pooyan"
symlinkfolder "_River Patrol"
symlinkfolder "_Labyrinth Runner"
symlinkfolder "_Scramble"
symlinkfolder "_Super Cobra"
symlinkfolder "_The End"
symlinkfolder "_Time Pilot"
symlinkfolder "_Time Pilot 84"
symlinkfolder "_Mr. Goemon"
symlinkfolder "_MX5000"
symlinkfolder "_JailBreak"
symlinkfolder "_Iron Horse"
symlinkfolder "_Jackal"
symlinkfolder "_Fast Lane"
symlinkfolder "_Scooter Shooter"
symlinkfolder "_Finalizer - Super Transformation"
symlinkfolder "_Kicker"
symlinkfolder "_Yie Ar Kung-Fu"


exit 0