 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Konami"
RegSourceRoot=/media/fat/_Arcade

cd $OutputRoot

create "$MainDir"

addgame "Amidar (Scramble).mra" "_Amidar"
addgame "Amidar.mra" "_Amidar"
addgame "Combat School Joystick.mra" "_Combat School"
addgame "Fast Lane.mra" "_Fast Lane"
addgame "Finalizer - Super Transformation (Set 1).mra" "_Finalizer - Super Transformation"
createlinkfile "Finalizer - Super Transformation (Set 2) [bl].mra" "_Finalizer - Super Transformation"
createlinkfile "Finalizer - Super Transformation (Set 2).mra" "_Finalizer - Super Transformation"
addgame "Frogger (Konami Bugfixed).mra" "_Frogger"
createlinkfile "Frogger (Sega, Set 2).mra" "_Frogger"
createlinkfile "Frogger.mra" "_Frogger"
addgame "Green Beret.mra" "_Green Beret"
addgame "Gyruss (bootleg).mra" "_Gyruss"
createlinkfile "Gyruss (Centuri).mra" "_Gyruss"
createlinkfile "Gyruss.mra" "_Gyruss"
addgame "Hyper Sports.mra" "_Hyper Sports"
addgame "Iron Horse (Ver. K).mra" "_Iron Horse"
addgame "Jackal (W) [bl].mra" "_Jackal"
createlinkfile "Jackal (W).mra" "_Jackal"
createlinkfile "Jackal (W, Rotary).mra" "_Jackal"
addgame "Jailbreak.mra" "_JailBreak"
addgame "Kicker.mra" "_Kicker"
addgame "Konami's Ping-Pong.mra" "_Konami's Ping-Pong"
addgame "Manhattan 24 Bunsyo (J).mra" "_JailBreak"
addgame "Mikie.mra" "_Mikie"
addgame "Mr. Goemon.mra" "_Mr. Goemon"
addgame "MX5000.mra" "_MX5000"
addgame "Nemesis (ROM Version).mra" "_Nemesis"
addgame "Pooyan.mra" "_Pooyan"
addgame "River Patrol (JP, Unprotected).mra" "_River Patrol"
createlinkfile "River Patrol.mra" "_River Patrol"
addgame "Road Fighter (set 1).mra" "_Road Fighter"
createlinkfile "Rush'n Attack (US).mra" "_Green Beret"
addgame "Scooter Shooter.mra" "_Scooter Shooter"
addgame "Scramble (Stern, Set 1).mra" "_Scramble"
addgame "Scramble.mra" "_Scramble"
addgame "Super Basketball (version I, encrypted).mra" "_Super Basketball"
addgame "Super Cobra.mra" "_Super Cobra"
addgame "The End (bkg).mra" "_The End"
addgame "The End.mra" "_The End"
addgame "Time Pilot '84 (Set 1).mra" "_Time Pilot 84"
createlinkfile "Time Pilot '84 (Set 2).mra" "_Time Pilot 84"
createlinkfile "Time Pilot '84 (Set 3).mra" "_Time Pilot 84"
createlinkfile "Time Pilot.mra" "_Time Pilot"
addgame "Tokushu Butai Jackal (JP).mra" "_Jackal"
createlinkfile "Top Gunner (US) [bl].mra" "_Jackal"
createlinkfile "Top Gunner (US).mra" "_Jackal"
addgame "Track & Field.mra" "_Track & Field"
addgame "Trick Trap (World).mra" "_Labyrinth Runner"
createlinkfile "Venus (bootleg of Gyruss).mra" "_Gyruss"
addgame "Yie Ar Kung-Fu (program code I).mra" "_Yie Ar Kung-Fu"
addgame "Roc'n Rope.mra" "_Roc'n Rope"


exit 0