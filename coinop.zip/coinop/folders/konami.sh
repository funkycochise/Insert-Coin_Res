 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Konami"

cd $OutputRoot

create "$MainDir"

copyfile "Amidar (Scramble).mra" "_Amidar"
copyfile "Amidar.mra" "_Amidar"
copyfile "Combat School Joystick.mra" "_Combat School"
copyfile "Fast Lane.mra" "_Fast Lane"
copyfile "Finalizer - Super Transformation (Set 1).mra" "_Finalizer - Super Transformation"
copyfile "Finalizer - Super Transformation (Set 2) [bl].mra" "_Finalizer - Super Transformation"
copyfile "Finalizer - Super Transformation (Set 2).mra" "_Finalizer - Super Transformation"
copyfile "Frogger (Konami Bugfixed).mra" "_Frogger"
copyfile "Frogger (Sega, Set 2).mra" "_Frogger"
copyfile "Frogger.mra" "_Frogger"
copyfile "Green Beret.mra" "_Green Beret"
copyfile "Gyruss (bootleg).mra" "_Gyruss"
copyfile "Gyruss (Centuri).mra" "_Gyruss"
copyfile "Gyruss.mra" "_Gyruss"
copyfile "Gyruss.mra" "_Gyruss"
copyfile "Hyper Sports.mra" "_Hyper Sports"
copyfile "Iron Horse (Ver. K).mra" "_Iron Horse"
copyfile "Jackal (W) [bl].mra" "_Jackal"
copyfile "Jackal (W).mra" "_Jackal"
copyfile "Jackal (W, Rotary).mra" "_Jackal"
copyfile "Jailbreak.mra" "_JailBreak"
copyfile "Kicker.mra" "_Kicker"
copyfile "Konami's Ping-Pong.mra" "_Konami's Ping-Pong"
copyfile "Manhattan 24 Bunsyo (J).mra" "_JailBreak"
copyfile "Mikie.mra" "_Mikie"
copyfile "Mr. Goemon.mra" "_Mr. Goemon"
copyfile "MX5000.mra" "_MX5000"
copyfile "Nemesis (ROM Version).mra" "_Nemesis"
copyfile "Pooyan.mra" "_Pooyan"
copyfile "River Patrol (JP, Unprotected).mra" "_River Patrol"
copyfile "River Patrol.mra" "_River Patrol"
copyfile "Road Fighter (set 1).mra" "_Road Fighter"
copyfile "Rush'n Attack (US).mra" "_Green Beret"
copyfile "Scooter Shooter.mra" "_Scooter Shooter"
copyfile "Scramble (Stern, Set 1).mra" "_Scramble"
copyfile "Scramble.mra" "_Scramble"
copyfile "Super Basketball (version I, encrypted).mra" "_Super Basketball"
copyfile "Super Cobra.mra" "_Super Cobra"
copyfile "The End (bkg).mra" "_The End"
copyfile "The End.mra" "_The End"
copyfile "Time Pilot '84 (Set 1).mra" "_Time Pilot 84"
copyfile "Time Pilot '84 (Set 2).mra" "_Time Pilot 84"
copyfile "Time Pilot '84 (Set 3).mra" "_Time Pilot 84"
copyfile "Time Pilot.mra" "_Time Pilot"
copyfile "Tokushu Butai Jackal (JP).mra" "_Jackal"
copyfile "Top Gunner (US) [bl].mra" "_Jackal"
copyfile "Top Gunner (US).mra" "_Jackal"
copyfile "Track & Field.mra" "_Track & Field"
copyfile "Trick Trap (World).mra" "_Labyrinth Runner"
copyfile "Venus (bootleg of Gyruss).mra" "_Gyruss"
copyfile "Yie Ar Kung-Fu (program code I).mra" "_Yie Ar Kung-Fu"

symlinkfolder "_Amidar"
symlinkfolder "_Combat School"
symlinkfolder "_Contra"
symlinkfolder "_Fast Lane"
symlinkfolder "_Finalizer - Super Transformation"
symlinkfolder "_Frogger"
symlinkfolder "_Green Beret"
symlinkfolder "_Gyruss"
symlinkfolder "_Hyper Sports"
symlinkfolder "_Iron Horse"
symlinkfolder "_Jackal"
symlinkfolder "_JailBreak"
symlinkfolder "_Kicker"
symlinkfolder "_Konami's Ping-Pong"
symlinkfolder "_Labyrinth Runner"
symlinkfolder "_Mikie"
symlinkfolder "_Mr. Goemon"
symlinkfolder "_MX5000"
symlinkfolder "_Nemesis"
symlinkfolder "_Pooyan"
symlinkfolder "_River Patrol"
symlinkfolder "_Road Fighter"
symlinkfolder "_Scooter Shooter"
symlinkfolder "_Scramble"
symlinkfolder "_Super Basketball"
symlinkfolder "_Super Cobra"
symlinkfolder "_The End"
symlinkfolder "_Time Pilot 84"
symlinkfolder "_Time Pilot"
symlinkfolder "_Track & Field"
symlinkfolder "_Yie Ar Kung-Fu"

#rocnrope
found=false
if  test -f "$RegSourceRoot/Roc'n Rope.mra"; then
  copyfile "Roc'n Rope.mra" "_Roc'n Rope"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Roc'n Rope"
else
  rm -r "$ALT/_Roc'n Rope" >/dev/null
fi

exit 0