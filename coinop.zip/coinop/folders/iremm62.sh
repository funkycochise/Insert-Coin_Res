 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M62 Hardware"

cd $OutputRoot

create "$MainDir"

addgame "Battle Road.mra" "_Battle Road"
addgame "Horizon (Irem).mra" "_Horizon"
createlinkfile "Horizon.mra" "_Horizon"
addgame "Kaiketsu Yancha Maru.mra" "_Kid Niki - Radical Ninja"
createlinkfile "Kid Niki - Radical Ninja (W).mra" "_Kid Niki - Radical Ninja"
createlinkfile "Kid Niki - Radical Ninja.mra" "_Kid Niki - Radical Ninja"
addgame "Kung-Fu Master (W).mra" "_Kung-Fu Master"
createlinkfile "Kung-Fu Master.mra" "_Kung-Fu Master"
addgame "Lode Runner (Set 1).mra" "_Lode Runner"
addgame "Lode Runner II - The Bungeling Strikes Back.mra" "_Lode Runner II"
addgame "Lode Runner III - The Golden Labyrinth.mra" "_Lode Runner III"
addgame "Lode Runner IV - Teikoku Karano Dasshutsu (JP).mra" "_Lode Runner IV"
createlinkfile "Lode Runner IV - Teikoku Karano Dasshutsu.mra" "_Lode Runner IV"
addgame "Lode Runner.mra" "_Lode Runner" "_Lode Runner"
createlinkfile "Spartan-X.mra" "_Kung-Fu Master"
addgame "Spelunker II - 23 no Kagi (JP).mra" "_Spelunker II"
addgame "Spelunker II - 23 no Kagi.mra" "_Spelunker II"
addgame "Spelunker.mra" "_Spelunker"
addgame "Youjyuden (JP).mra" "_Youjyuden"
createlinkfile "Youjyuden.mra" "_Youjyuden"

exit 0