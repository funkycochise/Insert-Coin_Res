 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Capcom-Mitchell"

cd $OutputRoot

create "$MainDir"

addgame  "1942.mra" "_1942"
addgame  "1943 Kai Midway Kaisen.mra" "_1943"
addgame  "1943 Midway Kaisen.mra" "_1943"
createlinkfile  "1943 The Battle of Midway Mark II.mra" "_1943"
createlinkfile  "1943 The Battle of Midway.mra" "_1943"
addgame  "Bionic Commando.mra" "_Bionic Commando"
addgame  "Black Tiger.mra" "_Black Tiger"
addgame  "Block Block (World 911219 Joystick).mra" "_Block Block"
addgame  "Capcom World (Japan).mra" "_Capcom World"
addgame  "Commando.mra" "_Commando"
addgame  "Dokaben (Japan).mra" "_Dokaben"
addgame  "Exed Exes.mra" "_Exed Exes"
addgame  "F-1 Dream.mra" "_F-1 Dream"
addgame  "Ghosts'n Goblins (World Set 1).mra" "_Ghosts'n Goblins"
addgame  "Gun Smoke.mra" "_Gun.Smoke"
addgame  "Legendary Wings.mra" "_Legendary Wings"
addgame  "Pang (World).mra" "_Pang"
addgame  "Pirate Ship Higemaru.mra" "_Pirate Ship Higemaru"
addgame  "Savage Bees.mra" "_Exed Exes"
addgame  "SectionZ.mra" "_SectionZ"
addgame  "Side Arms - Hyper Dyne (World, 861129).mra" "_Side Arms"
addgame  "Street Fighter (US, set 1).mra" "_Street Fighter"
addgame  "Super Pang (World 900914).mra" "_Super Pang"
addgame  "The Speed Rumbler (set 1).mra" "_The Speed Rumbler"
addgame  "Tiger Road.mra" "_Tiger Road"
addgame  "Trojan (Romstar).mra" "_Trojan"
addgame  "Vulgus.mra" "_Vulgus"

exit 0