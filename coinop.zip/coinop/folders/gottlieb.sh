 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Gottlieb"

cd $OutputRoot

create "$MainDir"

addgame "Curve Ball.mra" "_Curve Ball"
addgame "Insector.mra" "_Insector"
addgame "Mad Planets.mra" "_Mad Planets"
addgame "QBert Qubes.mra" "_QBert Qubes"
addgame "QBert.mra" "_QBert"
addgame "Tylz.mra" "_Tylz"

exit 0