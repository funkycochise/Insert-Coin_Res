 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Raizing-8ing"

cd $OutputRoot

create "$MainDir"

copyfile "Battle Garegga (Europe  USA  Japan  Asia) (Sat Feb 3 1996).mra" "_Battle Garegga"

symlinkfolder "_Batrider"
symlinkfolder "_Battle Bakraid"
symlinkfolder "_Battle Garegga"

exit 0