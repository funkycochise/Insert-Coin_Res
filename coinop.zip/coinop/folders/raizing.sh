 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

MainDir="_Raizing"

cd $OutputRoot

create "$MainDir"

copyfile "Armed Police Batrider (Europe) (Fri Feb 13 1998).mra" "_Batrider"
copyfile "Armed Police Batrider (USA) (Fri Feb 13 1998).mra" "_Batrider"
copyfile "Battle Bakraid - Unlimited Version (USA) (Tue Jun 8 1999).mra" "_Battle Bakraid"

symlinkfolder "_Batrider"
symlinkfolder "_Battle Bakraid"

exit 0