 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Raizing-8ing"

cd $OutputRoot

create "$MainDir"

copyfile "Armed Police Batrider (Europe) (Fri Feb 13 1998).mra" "_Batrider"
copyfile "Armed Police Batrider (USA) (Fri Feb 13 1998).mra" "_Batrider"
copyfile "Battle Bakraid - Unlimited Version (USA) (Tue Jun 8 1999).mra" "_Battle Bakraid
copyfile "Battle Garegga (Europe  USA  Japan  Asia) (Sat Feb 3 1996).mra" "_Battle Garegga"

symlinkfolder "_Batrider"
symlinkfolder "_Battle Bakraid"
symlinkfolder "_Battle Garegga"

exit 0