 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

MainDir="_Raizing"

cd $OutputRoot

create "$MainDir"

copyfile  "Armed Police Batrider (Europe) (Fri Feb 13 1998).mra" "_Batrider"
copyfile  "Armed Police Batrider (USA) (Fri Feb 13 1998).mra" "_Batrider"

symlinkfolder "_Batrider"

exit 0