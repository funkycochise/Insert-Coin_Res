 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Raizing-8ing"

cd $OutputRoot

create "$MainDir"

symlinkfolder "_Batrider"
symlinkfolder "_Battle Bakraid"

exit 0