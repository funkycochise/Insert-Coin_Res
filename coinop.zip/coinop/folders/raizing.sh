 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Raizing-8ing"
RegSourceRoot=/media/fat/_Arcade

cd $OutputRoot

create "$MainDir"

#batrider
found=false
if  test -f "$RegSourceRoot/Armed Police Batrider (USA) (Fri Feb 13 1998).mra"; then
  copyfile "Armed Police Batrider (USA) (Fri Feb 13 1998).mra" "_Batrider"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Batrider"
else
  rm -r "$ALT/"_Batrider" >/dev/null
fi
symlinkfolder "_Batrider"

exit 0