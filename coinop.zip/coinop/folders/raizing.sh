 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Raizing-8ing"
RegSourceRoot=/media/fat/_Arcade

cd $OutputRoot

create "$MainDir"

#batrider
found=false
if  test -f "$RegSourceRoot/Armed Police Batrider (USA) (Fri Feb 13 1998).mra"; then
  copyfile "Armed Police Batrider (USA) (Fri Feb 13 1998).mra" "_Batrider"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Batrider"
else
  rm -r "$ALT/_Batrider" >/dev/null
fi
#Bakraid
found=false
if  test -f "$RegSourceRoot/Battle Bakraid - Unlimited Version (USA) (Tue Jun 8 1999).mra"; then
  copyfile "Battle Bakraid - Unlimited Version (USA) (Tue Jun 8 1999).mra" "_Battle Bakraid"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Battle Bakraid"
else
  rm -r "$ALT/_Battle Bakraid" >/dev/null
fi
#Garegga
found=false
if  test -f "$RegSourceRoot/Battle Garegga (Europe  USA  Japan  Asia) (Sat Feb 3 1996).mra"; then
  copyfile "Battle Garegga (Europe  USA  Japan  Asia) (Sat Feb 3 1996).mra" "_Battle Garegga"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Battle Garegga"
else
  rm -r "$ALT/_Battle Garegga" >/dev/null
fi


exit 0