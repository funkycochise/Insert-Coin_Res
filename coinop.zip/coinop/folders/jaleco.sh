 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Jaleco"

cd $OutputRoot

create "$MainDir"

copyfile "Psychic 5 (World).mra" "_Psychic 5"

symlinkfolder "_Psychic 5"

exit 0