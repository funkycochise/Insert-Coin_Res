 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

MainDir="_Jaleco"

cd $OutputRoot

create "$MainDir"

  addgame "Psychic 5 (World).mra" "_Psychic 5"
  createlinkfile "Psychic 5 (Japan).mra" "_Psychic 5"
  addgame "Rod-Land (World, set 1).mra" "_Rod-Land"
  addgame "chameleon.mra" "_Chameleon"

exit 0