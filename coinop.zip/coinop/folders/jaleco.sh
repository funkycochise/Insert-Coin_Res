 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

RegSourceRoot=/media/fat/_Arcade
ALT=/media/fat/_Arcade/_alternatives

MainDir="_Jaleco"

cd $OutputRoot

create "$MainDir"

found=false
if  test -f "$RegSourceRoot/Psychic 5 (World).mra"; then
  copyfile "Psychic 5 (World).mra" "_Psychic 5"
  found=true
fi
if  test -f "$RegSourceRoot/Psychic 5 (Japan).mra"; then
  copyfile "Psychic 5 (Japan).mra" "_Psychic 5"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Psychic 5"
else
rm -r "$ALT/_Psychic 5" >/dev/null
fi
found=false
if  test -f "$RegSourceRoot/Rod-Land (World, set 1).mra"; then
  copyfile "Rod-Land (World, set 1).mra" "_Rod-Land"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Rod-Land"
else
rm -r "$ALT/_Rod-Land" >/dev/null
fi

exit 0