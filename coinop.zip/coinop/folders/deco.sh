 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Data East-Deco"

cd $OutputRoot

create "$MainDir"

copyfile "Bump 'n' Jump.mra" "_Burning Rubber"
copyfile "Burnin' Rubber.mra" "_Burning Rubber"
copyfile "Burger Time.mra" "_Burger Time"
copyfile "Burger Time (Set 1).mra" "_Burger Time"
copyfile "Bad Dudes vs. Dragonninja (US revision 1).mra" "_Bad Dudes vs. Dragonninja"
copyfile "Heavy Barrel (World).mra" "_Heavy Barrel"
copyfile "Robocop (World revision 4).mra" "_Robocop"

symlinkfolder "_Burning Rubber"
symlinkfolder "_Burger Time"
symlinkfolder "_Bad Dudes vs. Dragonninja"
symlinkfolder "_Heavy Barrel"
symlinkfolder "_Robocop"

exit 0