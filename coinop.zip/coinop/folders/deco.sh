 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Data East-Deco"

cd $OutputRoot

create "$MainDir"

copyfile "Bad Dudes vs. Dragonninja (US revision 1).mra" "_Bad Dudes vs. Dragonninja"
copyfile "Boulder Dash - Boulder Dash Part 2 (World).mra" "_Boulder Dash"
copyfile "Bump 'n' Jump.mra" "_Burning Rubber"
copyfile "Burger Time (Set 1).mra" "_Burger Time"
copyfile "Burger Time.mra" "_Burger Time"
copyfile "Burnin' Rubber.mra" "_Burning Rubber"
copyfile "Heavy Barrel (World).mra" "_Heavy Barrel"
copyfile "Hippodrome (US).mra" "_Hippodrome"
copyfile "Midnight Resistance (World).mra" "_Midnight Resistance"
copyfile "Robocop (World revision 4).mra" "_Robocop"
copyfile "Secret Agent (World revision 3).mra" "_Secret Agent"

symlinkfolder "_Bad Dudes vs. Dragonninja"
symlinkfolder "_Boulder Dash"
symlinkfolder "_Burger Time"
symlinkfolder "_Burning Rubber"
symlinkfolder "_Heavy Barrel"
symlinkfolder "_Hippodrome"
symlinkfolder "_Midnight Resistance"
symlinkfolder "_Robocop"
symlinkfolder "_Secret Agent"

found=false
if  test -f "$RegSourceRoot/Karate Champ (US).mra"; then
  copyfile "Karate Champ (US).mra" "_Karate Champ"
  found=true
fi
if [ "$found" = true ] ; then
  symlinkfolder "_Karate Champ"
else
  rm -r "$ALT/_Karate Champ" >/dev/null
fi

exit 0