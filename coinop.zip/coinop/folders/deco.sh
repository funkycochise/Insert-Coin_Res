 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Data East-Deco"

cd $OutputRoot

create "$MainDir"

copyfile "Bad Dudes vs. Dragonninja (US revision 1).mra" "_Bad Dudes vs. Dragonninja"
copyfile "Bump 'n' Jump.mra" "_Burning Rubber"
copyfile "Burger Time (Set 1).mra" "_Burger Time"
copyfile "Burger Time.mra" "_Burger Time"
copyfile "Burnin' Rubber.mra" "_Burning Rubber"
copyfile "Heavy Barrel (World).mra" "_Heavy Barrel"
copyfile "Hippodrome (US).mra" "_Hippodrome"
copyfile "Midnight Resistance (World).mra" "_Midnight Resistance"
copyfile "Robocop (World revision 4).mra" "_Robocop"

symlinkfolder "_Bad Dudes vs. Dragonninja"
symlinkfolder "_Burger Time"
symlinkfolder "_Burning Rubber"
symlinkfolder "_Heavy Barrel"
symlinkfolder "_Hippodrome"
symlinkfolder "_Midnight Resistance"
symlinkfolder "_Robocop"



exit 0