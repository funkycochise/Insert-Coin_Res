 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Data East-Deco"

cd $OutputRoot

create "$MainDir"

addgame "Bad Dudes vs. Dragonninja (US revision 1).mra" "_Bad Dudes vs. Dragonninja"
addgame "Boulder Dash - Boulder Dash Part 2 (World).mra" "_Boulder Dash"
addgame "Bump 'n' Jump.mra" "_Burning Rubber"
addgame "Burger Time (Set 1).mra" "_Burger Time"
createlinkfile "Burger Time.mra" "_Burger Time"
createlinkfile "Burnin' Rubber.mra" "_Burning Rubber"
addgame "Heavy Barrel (World).mra" "_Heavy Barrel"
addgame "Hippodrome (US).mra" "_Hippodrome"
addgame "Midnight Resistance (World).mra" "_Midnight Resistance"
addgame "Robocop (World revision 4).mra" "_Robocop"
addgame "Secret Agent (World revision 3).mra" "_Secret Agent"
addgame "Karate Champ (US).mra" "_Karate Champ"

exit 0