﻿#!/bin/bash
clear
exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null

TEMP=/media/fat/scripts/temp
MAME=/media/fat/games/mame
ARCHIVE_MERGED=https://ia601502.us.archive.org/13/items/mame-merged/mame-merged/


function dl {

FILE=$MAME/$1
if ! test -f "$FILE"; then
   #file doesn not exists
   special_echo "$1"
   curl $ARCHIVE_MERGED/$1 -O -k
   mv $TEMP/$1 $MAME/$1 
#else
#   special_echo "$1 already exixts"
fi

}

special_echo "Downloading missing mame roms"
rm -r $TEMP
mkdir $TEMP
cd $TEMP
dl "amazon.zip"
dl "aso.zip"
dl "choplift.zip"
dl "ddonpach.zip"
dl "esprade.zip"
dl "feversos.zip"
dl "gardia.zip"
dl "guwange.zip"
dl "hellfire.zip"
dl "horekid.zip"
dl "kicker.zip"
dl "myhero.zip"
dl "nemesis.zip"
dl "numcrash.zip"
dl "outzone.zip"
dl "pitfall2.zip"
dl "raflesia.zip"
dl "regulus.zip"
dl "sbasketb.zip"
dl "seganinj.zip"
dl "spatter.zip"
dl "starjack.zip"
dl "swat.zip"
dl "teddybb.zip"
dl "terracre.zip"
dl "tokisens.zip"
dl "truxton.zip"
dl "ufosensi.zip"
dl "uopoko.zip"
dl "upndown.zip"
dl "vigilant.zip"
dl "wb3.zip"
dl "wboy.zip"
dl "wmatch.zip"
dl "zerowing.zip"

cd /media/fat
rm -r "$TEMP"




