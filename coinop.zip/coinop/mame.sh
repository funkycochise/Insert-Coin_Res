﻿#!/bin/bash
clear
#exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null

launchdir=$1
#special_echo "launchdir $launchdir"
#echo "launchdir $launchdir"

TEMP=/media/fat/scripts/temp
SD=/media/fat
USB=/media/usb0
MAME=/media/fat/games/mame
MAMEUSB=/media/usb0/games/mame
ARCHIVE_MERGED=https://ia802504.us.archive.org/1/items/mame-merged/mame-merged


function dl {

if [ -d "$USB/games/mame" ]; then
  mametarget=$USB/games/mame
  arcade=$USB/_Arcade
else
  mametarget=$SD/games/mame
  arcade=$SD/_Arcade
  if ! [ -d "$mametarget" ]; then
    mkdir $mametarget
  fi
fi

if ! [ -z "$2" ]
then
  #special_echo "retrieve $2"
  if test -f "$arcade/$2"; then
    #special_echo "$2 exists"
    FILE=$mametarget/$1
    #special_echo "retrieve $FILE"
    if ! test -f "$FILE"; then
      special_echo "downloading $1"
      #file doesn not exists
      #special_echo "$1"
      curl $ARCHIVE_MERGED/$1 -O -k
      mv $TEMP/$1 $mametarget/$1 
    #else
#     special_echo "$1 already exixts"
   fi
  fi
fi

}

special_echo "Downloading missing mame roms"
cd $TEMP
dl "bgaregga.zip"
dl "kingdmgp.zip"
dl "sstriker.zip"

cd /media/fat
rm -r "$TEMP"
clear





