﻿#!/bin/bash
clear
#exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null

launchdir=$1
#special_echo "launchdir $launchdir"
#echo "launchdir $launchdir"

TEMP=/media/fat/scripts/temp
MAME=/media/fat/games/mame
ARCHIVE_MERGED=https://ia802504.us.archive.org/1/items/mame-merged/mame-merged


function dl {

if ! [ -d "$MAME" ]; then
  mkdir $MAME
fi

FILE=$MAME/$1
if ! test -f "$FILE"; then
   #file doesn not exists
   special_echo "$1"
   curl $ARCHIVE_MERGED/$1 -O -k
   mv $TEMP/$1 $MAME/$1 
#else
#   special_echo "$1 already exixts"
fi

}

special_echo "Downloading missing mame roms"
cd $TEMP
dl "amazon.zip"
dl "armedf.zip"
dl "aso.zip"
dl "athena.zip"
dl "batrider.zip"
dl "cclimbr2.zip"
dl "choplift.zip"
dl "ddonpach.zip"
dl "donpachi.zip"
dl "donpachi.zip"
dl "esprade.zip"
dl "feversos.zip"
dl "finalizr.zip"
dl "gaia.zip"
dl "gardia.zip"
dl "guwange.zip"
dl "hellfire.zip"
dl "horekid.zip"
dl "hyperspt.zip"
dl "kicker.zip"
dl "kozure.zip"
dl "legion.zip"
dl "mikie.zip"
dl "myhero.zip"
dl "nemesis.zip"
dl "numcrash.zip"
dl "outzone.zip"
dl "pang.zip"
dl "pingpong.zip"
dl "pitfall2.zip"
dl "raflesia.zip"
dl "regulus.zip"
dl "roadf.zip"
dl "sbasketb.zip"
dl "seganinj.zip"
dl "spang.zip"
dl "spatter.zip"
dl "starjack.zip"
dl "swat.zip"
dl "teddybb.zip"
dl "terracre.zip"
dl "theroes.zip"
dl "tnk3.zip"
dl "tokisens.zip"
dl "trackfld.zip"
dl "truxton.zip"
dl "ufosensi.zip"
dl "uopoko.zip"
dl "upndown.zip"
dl "vigilant.zip"
dl "wb3.zip"
dl "wboy.zip"
dl "wmatch.zip"
dl "yiear.zip"
dl "zerowing.zip"
dl "fitegolf.zip"
dl "psychic5.zip"
dl "megrescu.zip"
dl "dokaben.zip"
dl "cworld.zip"
dl "block.zip"
dl "rodland.zip"

cd /media/fat
rm -r "$TEMP"
clear





