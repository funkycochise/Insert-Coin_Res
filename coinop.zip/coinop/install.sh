#!/bin/bash

exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null

ZP="_Arcade_missing.zip"
TEMP=/media/fat/scripts/temp
ALT=/media/fat/_Arcade/_alternatives

function installfolder {
rm -r "$ALT/$1" >/dev/null
mv -v "$TEMP/_Arcade/_alternatives/$1" "$ALT" >/dev/null
}

special_echo "Getting missing resources"

mkdir $TEMP

cd $TEMP
rm -r _Arcade >/dev/null
rm $ZP >/dev/null

curl https://raw.githubusercontent.com/funkycochise/Coin-Op/master/$ZP -O -k
unzip $ZP -d $TEMP >/dev/null
rm $ZP

#delete all _Tetris folders in alternatives
echo "Remove _Tetris references in alternatives folder"
rm -r "$ALT/_Tetris" >/dev/null
rm -r "$ALT/_Atari Tetris" >/dev/null
echo "Updating SEGA System1/2 rbf core"
rm /media/fat/_Arcade/cores/SEGASYS1_*.rbf
mv -v $TEMP/_Arcade/SEGASYS1_*.rbf /media/fat/_Arcade/cores
echo "Installing MVS neogeo rbf core"
rm -r "/media/fat/_Arcade/Bang Bang Busters.mra" >/dev/null
mv -v $TEMP/_Arcade/neogeo.zip /media/fat/games/mame >/dev/null
rm -r /media/fat/_Arcade/cores/NeoGeo-MVS_*.rbf >/dev/null
mv -v $TEMP/_Arcade/NeoGeo-MVS_*.rbf /media/fat/_Arcade/cores
rm -r /media/fat/_Console/NeoGeo*.rbf >/dev/null
rm -r "/media/fat/_Arcade/Metal Slug 2t.mra" >/dev/null
mv -v $TEMP/_Console/NeoGeo*.rbf /media/fat/_Console/
echo "merging _Arcades with missing files and folders"
mv -v $TEMP/_Arcade/*.mra /media/fat/_Arcade
mv -v "$TEMP/_Arcade/_alternatives/_Tetris" "$ALT"
mv -v "$TEMP/_Arcade/_alternatives/_Atari Tetris" "$ALT"
rm -r "/media/fat/games/mame/s16mcu_alt.zip" >/dev/null
mv -v "$TEMP/_Arcade/s16mcu_alt.zip" "/media/fat/games/mame"
echo "Creating alternatives folders for Sega system 1 and 2"
installfolder "_Choplifter"
installfolder "_Gardia"
installfolder "_My Hero"
installfolder "_Pitfall II"
installfolder "_Rafflesia"
installfolder "_Regulus"
installfolder "_Sega Ninja"
installfolder "_Spatter"
installfolder "_Star Jacker"
installfolder "_SWAT"
installfolder "_TeddyBoy Blues"
installfolder "_Toki no Senshi"
installfolder "_UFO Senshi Youko Chan"
installfolder "_Up'n Down"
installfolder "_Water Match"
installfolder "_Wonder Boy"
installfolder "_Wonder Boy in Monster Land" 

rm -r "/media/fat/games/zerowing" >/dev/null
rm -r "/media/fat/_Arcade/Zero Wing*.mra" >/dev/null
rm -r "/media/fat/_Arcade/zerowing*.rbf" >/dev/null
mv -v $TEMP/_Arcade/zerowing*.rbf /media/fat/_Arcade/cores

cd /media/fat
rm -r "$TEMP"



