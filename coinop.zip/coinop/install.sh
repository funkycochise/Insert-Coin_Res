﻿#!/bin/bash
clear
#exec 3>&1
RED='\033[0;31m'
NC='\033[0m' # No Color
special_echo () {
    echo -e "$@" >&3
}
exec &>/dev/null

launchdir=$1
#special_echo "launchdir $launchdir"
#echo "launchdir $launchdir"

ZP="_Arcade_missing.zip"
TEMP=/media/fat/scripts/temp
ALT=/media/fat/_Arcade/_alternatives
MAME=/media/fat/games/mame
MAMEUSB=/media/usb0/games/mame
MAMECIFS=/media/fat/cifs/games/mame
ARCHIVE_MERGED=https://ia802504.us.archive.org/1/items/mame-merged/mame-merged

function installfolder {
if [ -d "$ALT/$1" ]; then
   #dir exists, remove
   rm -r "$ALT/$1" >/dev/null
fi
mv -v "$TEMP/_Arcade/_alternatives/$1" "$ALT" >/dev/null
}

function completefolder {
if [ -d "$ALT/$1" ]; then
   #dir exists
   cp "$TEMP/_Arcade/_alternatives/$1/*.mra" "$ALT/$1" >/dev/null
else
   mv -v "$TEMP/_Arcade/_alternatives/$1" "$ALT" >/dev/null
fi
}

function dl {

if ! [ -d "$MAME" ]; then
  mkdir $MAME
fi

FILE=$MAME/$1
if ! test -f "$FILE"; then
   #file doesn not exists
   special_echo "$1"
   curl $ARCHIVE_MERGED/$1 -O -k
   mv $TEMP/$1 $MAME/$1 
#else
#   special_echo "$1 already exixts"
fi

}

function mame {

if [ -d "$MAMEUSB" ]; then
  mametarget=$MAMEUSB
elif [ -d "$MAMECIFS" ]; then
  mametarget=$MAMECIFS
else
  mametarget=$MAME
  if ! [ -d "$MAME" ]; then
    mkdir $MAME
  fi
fi

rm -r "$mametarget/$1" >/dev/null
mv -v "$TEMP/_Arcade/$1" "$mametarget"

}


special_echo "${RED}"
special_echo " ▄████▄   ▒█████   ██▓ ███▄    █  ▒█████   ██▓███  "
special_echo "▒██▀ ▀█  ▒██▒  ██▒▓██▒ ██ ▀█   █ ▒██▒  ██▒▓██░  ██▒"
special_echo "▒▓█    ▄ ▒██░  ██▒▒██▒▓██  ▀█ ██▒▒██░  ██▒▓██░ ██▓▒"
special_echo "▒▓▓▄ ▄██▒▒██   ██░░██░▓██▒  ▐▌██▒▒██   ██░▒██▄█▓▒ ▒"
special_echo "▒ ▓███▀ ░░ ████▓▒░░██░▒██░   ▓██░░ ████▓▒░▒██▒ ░  ░"
special_echo "░ ░▒ ▒  ░░ ▒░▒░▒░ ░▓  ░ ▒░   ▒ ▒ ░ ▒░▒░▒░ ▒▓▒░ ░  ░"
special_echo "  ░  ▒     ░ ▒ ▒░  ▒ ░░ ░░   ░ ▒░  ░ ▒ ▒░ ░▒ ░     "
special_echo "░        ░ ░ ░ ▒   ▒ ░   ░   ░ ░ ░ ░ ░ ▒  ░░       "
special_echo "░ ░          ░ ░   ░           ░     ░ ░           "
special_echo "░   "
special_echo "${NC}"
special_echo "Updating coinop scripts"
sh ./scripts.sh $launchdir
special_echo "Downloading missing resources"
rm -r $TEMP
mkdir $TEMP
cd $TEMP
curl https://raw.githubusercontent.com/funkycochise/Coin-Op/master/$ZP -O -k
special_echo "Unzipping missing resources"
unzip $ZP -d $TEMP >/dev/null
rm $ZP
special_echo "Installing missing resources"	
rm -r "$ALT/_Double Dragon/Double Dragon.mra"
mv -f $TEMP/_Arcade/*.mra /media/fat/_Arcade

special_echo "SEGA System16 and Atari Tetris mras"
rm -r "$ALT/_Tetris" >/dev/null
rm -r "$ALT/_Atari Tetris" >/dev/null
installfolder "_Tetris"
installfolder "_Atari Tetris"

special_echo "SEGA System 1 and 2"
rm /media/fat/_Arcade/cores/SEGASYS1_*.rbf
mv -v $TEMP/_Arcade/SEGASYS1_*.rbf /media/fat/_Arcade/cores
installfolder "_Choplifter"
installfolder "_Gardia"
installfolder "_My Hero"
completefolder "_Pitfall II" 
installfolder "_Rafflesia"
installfolder "_Regulus"
installfolder "_Sega Ninja"
installfolder "_Spatter"
completefolder "_Star Jacker"
installfolder "_SWAT"
installfolder "_TeddyBoy Blues"
installfolder "_Toki no Senshi"
installfolder "_UFO Senshi Youko Chan"
installfolder "_Up'n Down"
installfolder "_Water Match"
installfolder "_Wonder Boy"
installfolder "_Wonder Boy in Monster Land" 

#in update_all
#special_echo "Cave"
rm -r "$ALT/_Cave68K" >/dev/null
#mv -v "$TEMP/_Arcade/Fever SOS.mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/Gaia Crusaders.mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/Thunder Heroes.mra" /media/fat/_Arcade
special_echo "SNK Neogeo arcade mras"
rm -r "/media/fat/_Arcade/Bang Bang Busters.mra" >/dev/null
rm -r "/media/fat/_Arcade/Metal Slug 2t.mra" >/dev/null
mame "neogeo.zip"
rm -r /media/fat/_Arcade/cores/NeoGeo-MVS_*.rbf >/dev/null
mv -v $TEMP/_Arcade/NeoGeo-MVS_*.rbf /media/fat/_Arcade/cores
mv -v "$TEMP/_Arcade/#neogeo.mgl" /media/fat/_Arcade/
rm -r /media/fat/_Console/NeoGeo_20211228.rbf >/dev/null
#rm -r /media/fat/_Console/NeoGeo*.rbf >/dev/null
#mv -v $TEMP/_Console/NeoGeo*.rbf /media/fat/_Console/

special_echo "SEGA System 16 mcu"
mame "s16mcu_alt.zip"

special_echo "Zaxxon samples"
mame "zaxxon_samples.zip"

special_echo "Konami Nemesis"
rm  /media/fat/_Arcade/cores/nemesis_beta*.rbf >/dev/null
rm "/media/fat/_Arcade/Nemesis (US).mra" >/dev/null
rm "/media/fat/_Arcade/Nemesis (UK).mra" >/dev/null
rm "/media/fat/_Arcade/_alternatives/_Nemesis/Nemesis (UK).mra"
rm "/media/fat/_Arcade/_alternatives/_Nemesis/Nemesis (US).mra"

#special_echo "Nichibutsu"
#completefolder "_Booby Kids"
#installfolder "_Soldier Girl Amazon"
#installfolder "_Terra Cresta"
#mv -v "$TEMP/_Arcade/Armed F (Japan).mra" /media/fat/_Arcade
rm -r /media/fat/_Arcade/cores/terracresta_20220430.rbf
rm -r /media/fat/_Arcade/cores/terracresta_20220326.rbf
#find /media/fat/_Arcade/ -maxdepth 1 -name 'armedf*' -exec rm -f {} \;
#mv -v $TEMP/_Arcade/armedf*.rbf /media/fat/_Arcade/cores
installfolder "_Formation Armed F"
mv -v "$TEMP/_Arcade/Legion - Spinner-87 (World ver 2.03).mra" /media/fat/_Arcade
installfolder "_Legion - Spinner-87"
rm -r "/media/fat/_Arcade/Armed F (Japan).mra"
mv -v "$TEMP/_Arcade/Armed F (Japan).mra" /media/fat/_Arcade

#special_echo "Raizing"
#rm -r /media/fat/_Arcade/cores/batrider*.rbf
#mv -v $TEMP/_Arcade/batrider*.rbf /media/fat/_Arcade/cores
#mv -v "$TEMP/_Arcade/Armed Police Batrider*.mra" /media/fat/_Arcade
installfolder "_Batrider"
#rm -r /media/fat/_Arcade/cores/bakraid*.rbf
#mv -v $TEMP/_Arcade/bakraid*.rbf /media/fat/_Arcade/cores
#mv -v "$TEMP/_Arcade/Battle Bakraid - Unlimited Version (USA) (Tue Jun 8 1999).mra" /media/fat/_Arcade
installfolder "_Battle Bakraid"
#rm -r /media/fat/_Arcade/cores/garegga*.rbf
#mv -v $TEMP/_Arcade/garegga*.rbf /media/fat/_Arcade/cores
#mv -v "$TEMP/_Arcade/Battle Garegga (Europe  USA  Japan  Asia) (Sat Feb 3 1996).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Kingdom Grandprix.mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Sorcer Striker.mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/Mahou Daisakusen (Japan).mra" /media/fat/_Arcade
installfolder "_Battle Garegga"

special_echo "Irem M72"
#rm -r /media/fat/_Arcade/cores/M72*.rbf
#mv -v $TEMP/_Arcade/M72*.rbf /media/fat/_Arcade/cores

rm -r /media/fat/_Arcade/cores/M72hh.rbf
#mv -v "$TEMP/_Arcade/Daiku no Gensan (Japan, M72 hardware).mra" /media/fat/_Arcade

#mv -v "$TEMP/_Arcade/Air Duel (Japan, M72 hardware).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Daiku no Gensan (Japan, M72 hardware).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Dragon Breed (Japan).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Gallop - Armed Police Unit (Japan).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Image Fight (Japan).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Image Fight (World).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Legend of Hero Tonma (Japan).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/Mr. HELI no Daibouken (Japan).mra" /media/fat/_Arcade
#rm -r "/media/fat/_Arcade/Ninja Spirit.mra"
#mv -v "$TEMP/_Arcade/Ninja Spirit (Japan).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/R-Type (Japan).mra" /media/fat/_Arcade
#mv -v "$TEMP/_Arcade/R-Type (World).mra" /media/fat/_Arcade
#rm -r "/media/fat/_Arcade/_alternatives/_Ninja Spirit/Ninja Spirit.mra"
rm -r "/media/fat/_Arcade/Ninja Spirit.mra"
rm -r "/media/fat/_Arcade/Ninja_Spirit.mra"
#mv -v "$TEMP/_Arcade/X Multiply (Japan, M72 hardware).mra" /media/fat/_Arcade
installfolder "_R-Type"
installfolder "_X Multiply"

special_echo "sfa3ce mra"
mv -v "$TEMP/_Arcade/Street Fighter Alpha 3 Challenger's Edition (USA 980904).mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/Street Fighter Zero 3 Challenger's Edition (USA 980904).mra" /media/fat/_Arcade

special_echo "Atari System1"
rm -r /media/fat/_Arcade/cores/Arcade-Atarisys1*.rbf
mv -v $TEMP/_Arcade/Arcade-Atarisys1*.rbf /media/fat/_Arcade/cores
mv -v "$TEMP/_Arcade/Indiana Jones.mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/Peter Pack Rat.mra" /media/fat/_Arcade
mame "vindctr2.zip"

#now in update_all
special_echo "SNK"
#mv -v $TEMP/_Arcade/ASO.mra /media/fat/_Arcade
#installfolder "_ASO"
installfolder "_TNKIII"
installfolder "_Athena"
#mv -v $TEMP/_Arcade/Athena.mra /media/fat/_Arcade

rm -r /media/fat/_Arcade/cores/Arcade-IkariWarriors_*.rbf
rm -r /media/fat/_Arcade/cores/IkariWarriors_20220713.rbf
rm -r /media/fat/_Arcade/cores/IkariWarriors_20220717.rbf
#mv -v $TEMP/_Arcade/Arcade-IkariWarrior*.rbf /media/fat/_Arcade/cores
mv -v "$TEMP/_Arcade/Ikari Warriors.mra" /media/fat/_Arcade#
mv -v "$TEMP/_Arcade/Victory Road.mra" /media/fat/_Arcade
installfolder "_Ikari Warriors"
installfolder "_Victory Road"

#special_echo "Namco Tank Battalion"
#mv -v $TEMP/_Arcade/Arcade-TankBattalion*.rbf /media/fat/_Arcade/cores
#rm -r "$TEMP/_Arcade/TankBattalion.mra" /media/fat/_Arcade
rm -r "/media/fat/_Arcade/cores/Arcade-TankBattalion_20220820.rbf"

special_echo "Toaplan Truxton II"
rm -r /media/fat/_Arcade/cores/truxton2_*.rbf
mv -v "$TEMP/_Arcade/Truxton II - Tatsujin Oh.mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/truxton2_20220902.rbf" /media/fat/_Arcade/cores
rm -r /media/fat/_Arcade/_alternatives/_Truxton2
installfolder "_Truxton II"

#special_echo "Missile Command"
rm -r "/media/fat/_Arcade/Missile_Command.mra"
rm -r "/$ALT/_Missile_Command/Missile_Command.mra"
#mv -v "$TEMP/_Arcade/Missile_Command.mra" /media/fat/_Arcade
rm -r "/media/fat/_Arcade/cores/Arcade-MissileCommand_20220823.rbf" 

special_echo "Prehistoric Isle in 1930"
installfolder "_Prehistoric Isle in 1930"
rm -r /media/fat/_Arcade/cores/prehisle_*.rbf
#mv -v "$TEMP/_Arcade/Prehistoric Isle in 1930 (World).mra" /media/fat/_Arcade
mv -v $TEMP/_Arcade/prehisle_*.rbf /media/fat/_Arcade/cores


special_echo "Final Fight AE CPS2"
mame "ffightae_cps2_gfx.zip"
mame "ffightae_cps2_smp.zip"
mv -v "$TEMP/_Arcade/Final Fight AE CPS2 Patch.mra" /media/fat/_Arcade

special_echo "Jaleco Psychic 5"
rm -r /media/fat/_Arcade/cores/ikacore_Psychic5_*.rbf
mv -v "$TEMP/_Arcade/Psychic 5 (Japan).mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/Psychic 5 (World).mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/ikacore_Psychic5_20220702.rbf" /media/fat/_Arcade/cores

special_echo "Toaplan Snow Bros. 2"
mv -v "$TEMP/_Arcade/Snow Bros. 2 - With New Elves - Otenki Paradise (Hanafram).mra" /media/fat/_Arcade
mv -v "$TEMP/_Arcade/snowbro2_20220904.rbf" /media/fat/_Arcade/cores
