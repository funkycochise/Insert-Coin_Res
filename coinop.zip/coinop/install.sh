#!/bin/bash

# redirect stdout/stderr to a file
exec >/dev/null 2>&1

ZP="_Arcade_missing.zip"
TEMP=/media/fat/scripts/temp
ALT=/media/fat/_Arcade/_alternatives

function installfolder {
rm -r "$ALT/$1" >/dev/null
mv -v "$TEMP/_Arcade/_alternatives/$1" "$ALT" >/dev/null
}

mkdir $TEMP

cd $TEMP
rm -r _Arcade >/dev/null
rm $ZP >/dev/null

curl https://raw.githubusercontent.com/funkycochise/Coin-Op/master/$ZP -O -k
unzip $ZP -d $TEMP >/dev/null
rm $ZP

#delete all _Tetris folders in alternatives
echo "Remove _Tetris references in alternatives folder"
rm -r "$ALT/_Tetris" >/dev/null
rm -r "$ALT/_Atari Tetris" >/dev/null
echo "Updating SEGA System1/2 rbf core"
rm /media/fat/_Arcade/cores/SEGASYS1_*.rbf
mv -v $TEMP/_Arcade/SEGASYS1_*.rbf /media/fat/_Arcade/cores
echo "merging _Arcades with missing files and folders"
mv -v $TEMP/_Arcade/*.mra /media/fat/_Arcade
mv -v "$TEMP/_Arcade/_alternatives/_Tetris" "$ALT"
mv -v "$TEMP/_Arcade/_alternatives/_Atari Tetris" "$ALT"
echo "Creating alternatives folders for Sega system 1 and 2"
installfolder "_Choplifter"
installfolder "_Gardia"
installfolder "_My Hero"
installfolder "_Pitfall II"
installfolder "_Rafflesia"
installfolder "_Regulus"
installfolder "_Sega Ninja"
installfolder "_Spatter"
installfolder "_Star Jacker"
installfolder "_SWAT"
installfolder "_TeddyBoy Blues"
installfolder "_Toki no Senshi"
installfolder "_UFO Senshi Youko Chan"
installfolder "_Up'n Down"
installfolder "_Water Match"
installfolder "_Wonder Boy"
installfolder "_Wonder Boy in Monster Land" 

cd /media/fat
rm -r "$TEMP"



