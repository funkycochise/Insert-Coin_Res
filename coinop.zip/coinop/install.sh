﻿#!/bin/bash
clear
exec 3>&1
special_echo () {
    echo "$@" >&3
}
exec &>/dev/null

ZP="_Arcade_missing.zip"
TEMP=/media/fat/scripts/temp
ALT=/media/fat/_Arcade/_alternatives

function installfolder {
if [ -d "$ALT/$1" ]; then
   #dir exists, remove
   rm -r "$ALT/$1" >/dev/null
fi
mv -v "$TEMP/_Arcade/_alternatives/$1" "$ALT" >/dev/null
}

function completefolder {
if [ -d "$ALT/$1" ]; then
   #dir exists
   cp "$TEMP/_Arcade/_alternatives/$1/*.mra" "$ALT/$1" >/dev/null
else
   mv -v "$TEMP/_Arcade/_alternatives/$1" "$ALT" >/dev/null
fi
}

special_echo " ▄████▄   ▒█████   ██▓ ███▄    █  ▒█████   ██▓███  "
special_echo "▒██▀ ▀█  ▒██▒  ██▒▓██▒ ██ ▀█   █ ▒██▒  ██▒▓██░  ██▒"
special_echo "▒▓█    ▄ ▒██░  ██▒▒██▒▓██  ▀█ ██▒▒██░  ██▒▓██░ ██▓▒"
special_echo "▒▓▓▄ ▄██▒▒██   ██░░██░▓██▒  ▐▌██▒▒██   ██░▒██▄█▓▒ ▒"
special_echo "▒ ▓███▀ ░░ ████▓▒░░██░▒██░   ▓██░░ ████▓▒░▒██▒ ░  ░"
special_echo "░ ░▒ ▒  ░░ ▒░▒░▒░ ░▓  ░ ▒░   ▒ ▒ ░ ▒░▒░▒░ ▒▓▒░ ░  ░"
special_echo "  ░  ▒     ░ ▒ ▒░  ▒ ░░ ░░   ░ ▒░  ░ ▒ ▒░ ░▒ ░     "
special_echo "░        ░ ░ ░ ▒   ▒ ░   ░   ░ ░ ░ ░ ░ ▒  ░░       "
special_echo "░ ░          ░ ░   ░           ░     ░ ░           "
special_echo "░   "
special_echo "Getting and installing missing resources"
mkdir $TEMP
cd $TEMP
rm -r _Arcade >/dev/null
rm $ZP >/dev/null
curl https://raw.githubusercontent.com/funkycochise/Coin-Op/master/$ZP -O -k
unzip $ZP -d $TEMP >/dev/null
rm $ZP
special_echo "Toaplan1 core"
find /media/fat/_Arcade/ -maxdepth 1 -name 'Zero Wing*' -exec rm -f {} \;
find /media/fat/_Arcade/ -maxdepth 1 -name 'Zero Wing2*' -exec rm -f {} \;
find /media/fat/_Arcade/ -maxdepth 1 -name 'Out Zone*' -exec rm -f {} \;
rm -r "/media/fat/games/zerowing" >/dev/null
rm -r "/media/fat/_Arcade/Out Zone*.mra" >/dev/null
rm -r "/media/fat/_Arcade/Hellfire*.mra" >/dev/null
rm -r "/media/fat/_Arcade/Truxton - Tatsujin.mra" >/dev/null
find /media/fat/_Arcade/cores -maxdepth 1 -name 'Zero Wing*.rbf' -exec rm -f {} \;
find /media/fat/_Arcade/cores -maxdepth 1 -name 'zerowing*.rbf' -exec rm -f {} \;
find /media/fat/_Arcade/cores -maxdepth 1 -name 'Zerowing*.rbf' -exec rm -f {} \;
find /media/fat/_Arcade/cores -maxdepth 1 -name 'nemesis*.rbf' -exec rm -f {} \;
find /media/fat/_Arcade/cores -maxdepth 1 -name 'toaplan1*.rbf' -exec rm -f {} \;

mv -v $TEMP/_Arcade/toaplan1*.rbf /media/fat/_Arcade/cores
installfolder "_Hellfire"
installfolder "_Out Zone"
installfolder "_Zero Wing"	
rm -r "$ALT/_Double Dragon/Double Dragon.mra"
mv -f $TEMP/_Arcade/*.mra /media/fat/_Arcade

special_echo "SEGA System16 and Atari Tetris mras"
rm -r "$ALT/_Tetris" >/dev/null
rm -r "$ALT/_Atari Tetris" >/dev/null
installfolder "_Tetris"
installfolder "_Atari Tetris"

special_echo "SEGA System 1 and 2"
rm /media/fat/_Arcade/cores/SEGASYS1_*.rbf
mv -v $TEMP/_Arcade/SEGASYS1_*.rbf /media/fat/_Arcade/cores
installfolder "_Choplifter"
installfolder "_Gardia"
installfolder "_My Hero"
completefolder "_Pitfall II" 
installfolder "_Rafflesia"
installfolder "_Regulus"
installfolder "_Sega Ninja"
installfolder "_Spatter"
completefolder "_Star Jacker"
installfolder "_SWAT"
installfolder "_TeddyBoy Blues"
installfolder "_Toki no Senshi"
installfolder "_UFO Senshi Youko Chan"
installfolder "_Up'n Down"
installfolder "_Water Match"
installfolder "_Wonder Boy"
installfolder "_Wonder Boy in Monster Land" 

special_echo "Cave mras"
special_echo "SNK Neogeo arcade mras"
rm -r "/media/fat/_Arcade/Bang Bang Busters.mra" >/dev/null
rm -r "/media/fat/_Arcade/Metal Slug 2t.mra" >/dev/null
mv -v $TEMP/_Arcade/neogeo.zip /media/fat/games/mame >/dev/null
mv -v $TEMP/neogeo/*.mra /media/fat/_Arcade
rm -r /media/fat/_Arcade/cores/NeoGeo-MVS_*.rbf >/dev/null
mv -v $TEMP/_Arcade/NeoGeo-MVS_*.rbf /media/fat/_Arcade/cores

rm -r /media/fat/_Console/NeoGeo_20211228.rbf >/dev/null
#rm -r /media/fat/_Console/NeoGeo*.rbf >/dev/null
#mv -v $TEMP/_Console/NeoGeo*.rbf /media/fat/_Console/

special_echo "SEGA System 16 mcu"
rm -r "/media/fat/games/mame/s16mcu_alt.zip" >/dev/null
mv -v "$TEMP/_Arcade/s16mcu_alt.zip" "/media/fat/games/mame"

special_echo "Konami Nemesis"
mv -v $TEMP/_Arcade/nemesis*.rbf /media/fat/_Arcade/cores

special_echo "Nichibutsu"
installfolder "_Booby Kids"
installfolder "_Soldier Girl Amazon"
installfolder "_Terra Cresta"

cd /media/fat
rm -r "$TEMP"
clear



